/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees;

/**
 * This class contains the calculations of the EmployeeSalary.
 * 
 * @author Avinash Vasadi
 */
public class EmployeeSalary {
//Declared the variables

    private double hourlyRate;
    private double Bonus;
    private double insuranceRate;
    private double taxRate;
    private int HOURS = 30;

/**
 * Created a EmployeeSalary Constructor with four arguments
 * @param hourlyRate Hourly pay rate of the employee
 * @param bonus Bonus amount per annum
 * @param insuranceRate Insurance percentage
 * @param taxRate Tax percentage
 */    

    public EmployeeSalary(double hourlyRate, double bonus, double insuranceRate, double taxRate) {
        this.hourlyRate = hourlyRate;
        this.Bonus = bonus;
        this.insuranceRate = insuranceRate;
        this.taxRate = taxRate;
    }
    /**
     * Created a EmployeeSalary Constructor with no arguments
     */


    public EmployeeSalary() {
        this.hourlyRate = 0.0;
        this.Bonus = 0.0;
        this.insuranceRate = 0.0;
        this.taxRate = 0.0;
    }


//get method to hourlyrate
    /**
     *Creating Setter and Getter methods
     * @return double
     */
    public double gethourlyRate() {
        return hourlyRate;
    }

    /**
     *get method to bonus
     * @return double
     */
    public double getBonus() {
        return Bonus;
    }

    /**
     *get method to insuranceRate
     * @return double
     */
    public double getinsuranceRate() {
        return insuranceRate;
    }

    /**
     *get method to taxRate
     * @return double
     */
    public double gettaxRate() {
        return taxRate;
    }

    /**
     *get method to HOURS
     * @return double
     */
    public int getHOURS() {
        return HOURS;
    }

    /**
     *set method to hourlyRate
     * @param hourlyRate Hourly pay rate of the employee
     */
    public void sethourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    /**
     *set method to Bonus
     * @param Bonus Bonus amount per annum
     */
    public void setBonus(double Bonus) {
        this.Bonus = Bonus;
    }

    /**
     *set method to insurance Rate
     * @param insuranceRate Insurance percentage
     */
    public void setinsuranceRate(double insuranceRate) {
        this.insuranceRate = insuranceRate;
    }

    /**
     *set method to taxRate
     * @param taxRate Tax percentage
     */
    public void settaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    /**
     *set method to HOURS
     * @param HOURS Total hours of work per week
     */
    public void setHOURS(int HOURS) {
        this.HOURS = HOURS;
    }

    /**
     *method to find monthlySalary
     * @return double
     */
    public double monthlySalary() {
        return (4 * this.HOURS * this.hourlyRate);
    }

    /**
     *method to find monthlyInsurance
     * @return double
     */
    public double monthlyInsurance() {
        return (4 * HOURS * this.hourlyRate * (this.insuranceRate / 100));
    }

    /**
     *method to find annualGrossSalary
     * @return double
     */
    public double annualGrossSalary() {
        return (12 * this.monthlySalary() + this.Bonus);
    }

    /**
     *method to find annualNetPay
     * @return double
     */
    public double annualNetPay() {
        return ((this.annualGrossSalary() * (1 - (3.2 / 100)))
                - (this.annualGrossSalary() * ((this.taxRate / 100)))
                - ((12 * this.monthlySalary()) * (this.insuranceRate / 100)));
    }

    /**
     *overriding toString method
     * @return string
     */
    
    @Override
    public String toString() {
        return ("Hourly pay rate:$" + this.hourlyRate + ", insurancerate:"
                + this.insuranceRate + "%, tax:" + this.taxRate + "%, annual bonus:$"
                + this.Bonus + ", Hours per week:" + this.HOURS + "\nThe monthly salary of the Employee is:$"
                + this.monthlySalary() + "\nThe monthly insurance of the Employee is:"
                + this.monthlyInsurance() + "\nThe annual gross salary of the Employee is:$"
                + this.annualGrossSalary() + "\nThe annual gross annual net pay of the Employee is:$"
                + this.annualNetPay());
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees;


import java.util.Scanner;

/**
 *  This class contains the main method
 * 
 * @author Avinash Vasadi
 */
public class EmployeeDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // created the employee object with 4 argument constructor
        Employee empObject01 = new Employee("Lousie", "Adams", 34562, "6602240486", "9277 Fairway Drive, Apt#208, Des Plaines, IL");
        System.out.println("Employee Details01");
        System.out.println("Employee ID: " + empObject01.getEmployeeID());
        System.out.println("Name: " + empObject01.getFirstName() + " " + empObject01.getLastName());
        System.out.println("Address: " + empObject01.getAddress());
        System.out.println("Contact Number: " + empObject01.getPhoneNumber());
        System.out.println("**************************************************\n");
// created the employee object with no-argument constructor
        Employee empObject02 = new Employee();
        System.out.println("Employee Details02");
        System.out.println("Employee ID: " + empObject02.getEmployeeID());
        System.out.println("Name: " + empObject02.getFirstName() + " " + empObject02.getLastName());
        System.out.println("Address: " + empObject02.getAddress());
        System.out.println("Contact Number: " + empObject02.getPhoneNumber());
        System.out.println("**************************************************\n");
/* empobject02 is created with the help of no argument Employee constructor in which default values are given as null & 0 for string & int, present in Employee class.
        So while calling the no argument constructor it printing the default values of that datatypes in that constructor.   */      
// now set the value of attributes for the empObject02
        empObject02.setEmployeeID(12354);
        empObject02.setFirstName("Jaden");
        empObject02.setLastName("Smith");
        empObject02.setPhoneNumber("9494949494");
        empObject02.setAddress("1231 University Drive, Apt#60, Kansas, MO");
        System.out.println("Testing toString() method of Employee class:\n" + empObject02.toString());
        System.out.println("**************************************************\n"
                + "\n"
                + "Testing the EmployeeSalary class:");
//Declare & Intialise the scaneer object and prompt the required values
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the hourly pay rate of the Employee : $");
        double hourlyRate = sc.nextDouble();
        System.out.print("Enter the insurance rate of the Employee in percentage:");
        double insuranceRate = sc.nextDouble();
        System.out.print("Enter the tax rate of the Employee in percentage:");
        double taxRate = sc.nextDouble();
        System.out.print("Enter the bonus amount:$ ");
        double Bonus = sc.nextDouble();
        System.out.println("**************************************************\n"
                + "\n"
                + "Testing the tostring() method of EmployeeSalary class :  ");
//Created the EmployeeSalary object with arguments        
        EmployeeSalary EmployeeSalaryObj1 = new EmployeeSalary(hourlyRate, Bonus, insuranceRate, taxRate);
        System.out.println(EmployeeSalaryObj1.toString());
        System.out.println("**************************************************\n"
                + "\n"
                + "The details of the EmployeeSalaryObj2 are as follows:\n"
                + "Testing the toString() method of EmployeeSalary class :");
//Created the EmployeeSalary object without arguments        
        EmployeeSalary EmployeeSalaryObj2 = new EmployeeSalary();
        System.out.println(EmployeeSalaryObj2.toString());
//now set the value of attributes for the EmployeeSalaryObj2
        EmployeeSalaryObj2.sethourlyRate(56.72);
        EmployeeSalaryObj2.setinsuranceRate(18.40);
        EmployeeSalaryObj2.settaxRate(9.65);
        EmployeeSalaryObj2.setBonus(8463.77);
        System.out.println("**************************************************\n"
                + "\n"
                + "Testing the toString() method of EmployeeSalary class :  ");
        System.out.println(EmployeeSalaryObj2.toString());
    }

}

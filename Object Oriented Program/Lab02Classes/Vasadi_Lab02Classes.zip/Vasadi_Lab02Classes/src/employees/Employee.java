/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees;

/**
 *This class contains details of the employee.
 * @author  Avinash Vasadi
 */
public class Employee {
//Declared the variables
    private String firstname;
    private String lastname;
    private int employeeID;
    private String phonenumber;
    private String address;
//Created Employee Constructor with five arguments
    /**
     * A constructor with arguments
     * @param firstname First name of the employee
     * @param lastname Last name of the employee
     * @param employeeID ID of the employee
     * @param phonenumber Phone number of the employee
     * @param address Address of the employees
     */
    public Employee(String firstname, String lastname, int employeeID, String phonenumber, String address) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.employeeID = employeeID;
        this.phonenumber = phonenumber;
        this.address = address;
    }
//Created Employee Constructor with no arguments
    /**
     * A constructor without arguments
     */
    public Employee() {
        this(null, null, 0, null, null);
    }
//Creating Setter and Getter methods    
/**
 *  It gets FirstName of the employee
 * @return string
 */
    public String getFirstName() {
        return firstname;
    }
/**
 * It gets LastName of the employee
 * @return string
 */
    public String getLastName() {
        return lastname;
    }
/**
 * It gets EmployeeID of the employee
 * @return string
 */
    public int getEmployeeID() {
        return employeeID;
    }
/**
 * It gets PhoneNumber of the employee
 * @return string
 */
    public String getPhoneNumber() {
        return phonenumber;
    }
/**
 * It gets Address of the employee
 * @return string
 */
    public String getAddress() {
        return address;
    }
/**
 * It sets firstName of the employee
 * @param firstname First name of the employee
 */
    public void setFirstName(String firstname) {
        this.firstname = firstname;
    }
/**
 * It sets the lastName of the employee
 * @param lastname Last name of the employee
 */
    public void setLastName(String lastname) {
        this.lastname = lastname;
    }
/**
 * It sets the EmployeeID of the employee
 * @param employeeID ID of the employee
 */
    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }
/**
 * It sets the phoneNumber of the employee
 * @param phonenumber Phone number of the employee
 */
    public void setPhoneNumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }
/**
 * It sets the Address of the employee
 * @param address Address of the employees
 */
    public void setAddress(String address) {
        this.address = address;
    }
/**
 * It overrides the toString method
 * @return string
 */
    @Override
    public String toString() {
        return (this.firstname + " " + this.lastname + " with" + " " + "employeeID: " + this.employeeID + "," + "phonenumber: " + this.phonenumber + " and address: " + this.address);
    }
}

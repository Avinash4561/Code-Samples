/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 *
 * @author Avinash Vasadi
 */
public class CircularQueue {

    int[] cirQue;
    int headIndex;
    int tailIndex;
    int eleCount;
    public static final int MAXELE = 50;

    /**
     * no-arg constructor.
     */
    public CircularQueue() {
        cirQue = new int[MAXELE];
        headIndex = 0;
        tailIndex = 0;
        eleCount = 0;
    }

    /**
     * check if the queue is empty
     *
     * @return boolean
     */
    public boolean isEmpty() {
        return eleCount == 0;
    }

    /**
     * check if the queue is full
     *
     * @return boolean
     */
    public boolean isFull() {
        return eleCount == MAXELE;
    }

    /**
     * insert a value to the queue at the end of the queue
     *
     * @param val number to insert
     */
    public void insert(int val) {
        try {
            if (!isFull()) {
                cirQue[tailIndex % MAXELE] = val;
                tailIndex = (tailIndex + 1) % MAXELE;
                eleCount++;
            } else {
                throw new CircularQueueFullException("Cannot insert toa full Queue!");
            }
        } catch (CircularQueueFullException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * remove an element form the front of the queue
     */
    public void remove() {
        try {
            if (!isEmpty()) {
                headIndex = (headIndex + 1) % MAXELE;
                eleCount--;
            } else {
                throw new CircularQueueEmptyException("Cannot remove from empty queue!");
            }
        } catch (CircularQueueEmptyException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * retrieve the first element of the queue
     *
     * @return integer at headIndex
     */
    public int retrieve() {
        try {

            if (!isEmpty()) {
                return cirQue[headIndex];
            } else {
                throw new CircularQueueEmptyException("Cannot retrive from empty queue!");
            }
        } catch (CircularQueueEmptyException e) {
            System.out.print(e.getMessage());
            return -1;
        }
    }

    /**
     * get the number of elements in the queue
     *
     * @return int
     */
    public int length() {
        return eleCount;
    }

    /**
     * get all the elements for the queue from headIndex to tailIndex
     *
     * @return String
     */
    public String print() {
        String values = "";
        if (length() > 0) {
            if (headIndex < tailIndex) {
                for (int i = headIndex; i < tailIndex; i++) {
                    values += cirQue[i] + " ";
                }
            } else {
                for (int i = headIndex; i < MAXELE; i++) {
                    values += cirQue[i] + " ";
                }
                for (int j = 0; j < tailIndex; j++) {
                    values += cirQue[j] + " ";
                }
            }
            return values;
        } else {
            return "The queue is empty";
        }
    }

   

}

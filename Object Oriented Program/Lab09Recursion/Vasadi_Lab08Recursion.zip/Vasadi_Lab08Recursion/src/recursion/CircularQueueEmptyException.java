/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 * An exception class to perform whether the Queue is empty or not.
 * @author Avinash Vasadi
 */
public class CircularQueueEmptyException extends Exception {

    public CircularQueueEmptyException(String msg) {
        super(msg);
    }

}

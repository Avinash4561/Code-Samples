/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Avinash Vasadi
 */
public class RecursionWorksheet {

    /**
     * A method to find GCD of two numbers.
     * @param a first number
     * @param b second number 
     * @return  integer
     */
    public static int GCD(int a, int b) {

        if (b == 0) {
            return a;
        } else {
            return GCD(b, a % b);
        }

    }

    /**
     * A method to perform the sum of squares.
     *
     * @param n a integer value
     * @return integer
     */
    public static int f(int n) {
        if (n == 0) {
            return 0;
        } else {
            return n * n + f(n - 1);
        }
    }

    /**
     * A method to calculate the factorial of a number.
     *
     * @param n number to find factorial
     * @return Integer
     */
    public static int fact(int n) {
        if (n == 0) {
            return 1;
        } else {
            return n * fact(n - 1);
        }
    }

    /**
     * A method to perform mystery
     *
     * @param n a number of type long
     */
    public static void mystery(long n) {
        System.out.print(n % 10);
        if ((n / 10) != 0) {
            mystery(n / 10);
        }
    }

    /**
     * A method to perform recursive sort.
     *
     * @param array array to sort
     * @param startIndex initial index value
     */
    public static void sort(int[] array, int startIndex) {
        if (startIndex >= array.length - 1) {
            return;
        }
        int minIndex = startIndex;
        for (int index = startIndex + 1; index < array.length; index++) {
            if (array[index] < array[minIndex]) {
                minIndex = index;
            }
        }
        int temp = array[startIndex];
        array[startIndex] = array[minIndex];
        array[minIndex] = temp;
        sort(array, startIndex + 1);
    }

    /**
     * A method to perform palindrome.
     *
     * @param s A input String
     * @return boolean
     */
    public static boolean Palindrome(String s) {
        if (s.length() == 0 || s.length() == 1) {
            return true;
        }
        if (s.charAt(0) == s.charAt(s.length() - 1)) {
            return Palindrome(s.substring(1, s.length() - 1));
        } else {
            return false;
        }
    }

    /**
     * A Main method to perform the required operations.
     *
     * @param args 
     */
    public static void main(String[] args) {
        System.out.println("**************************************");
        System.out.println(GCD(18, 12));
        System.out.println(GCD(9, 8));
        System.out.println(GCD(48, 39));
        System.out.println(GCD(12, 15));
        System.out.println(GCD(1234, 456));
        System.out.println("**************************************");

        System.out.println(f(2));
        System.out.println(f(3));
        System.out.println(f(5));
        System.out.println(f(10));
        System.out.println("It is the sum of squares of n");
        System.out.println("**************************************");

        System.out.println(fact(2));
        System.out.println(fact(3));
        System.out.println(fact(5));
        System.out.println(fact(7));
        System.out.println("**************************************");

        mystery(29);
        mystery(12345);
        System.out.println("\nIt is reversing the number");
        System.out.println("**************************************");

        int[] randomNumbers = new int[50];
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        for (int k = 0; k < 50; k++) {
            numbers.add(k + 1);
        }
        Collections.shuffle(numbers);
        int index = 0;
        for (int values : numbers) {
            randomNumbers[index] = values;
            index++;
        }
        System.out.println("Before Sorting : " + Arrays.toString(randomNumbers));
        sort(randomNumbers, 0);
        System.out.println("After Sorting : " + Arrays.toString(randomNumbers));

        System.out.println("**************************************");

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a String ");
        String input = sc.nextLine();
        input = input.trim();
        input = input.toLowerCase();
        System.out.println("Whether the given string is palindrome or not: " + Palindrome(input));

        System.out.println("**************************************");
        CircularQueue CQ = new CircularQueue();

        for (int i = 0; i <= 50; i++) {
            CQ.insert(i * 2);
        }
        System.out.println(CQ.print());

        CQ.remove();
        CQ.remove();
        CQ.remove();
        System.out.println(CQ.print());

        System.out.println("Element pointing to start Index" + CQ.retrieve());

        for (int i = 0; i <= 47; i++) {
            CQ.remove();
        }

        System.out.println(CQ.print());

        System.out.println("The length of Queue: " + CQ.length());

        System.out.println("Whether the Queue is empty or not: " + CQ.isEmpty());

        System.out.println("Whether the Queue is Full or not: " + CQ.isFull());

    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recursion;

/**
 * An Exception class to throw whether Queue is full or not.
 *
 * @author Avinash Vasadi
 */
public class CircularQueueFullException extends Exception {

    public CircularQueueFullException(String msg) {
        super(msg);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package setsandmaps;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

/**
 *
 * @author Avinash Vasadi
 */
public class MovieDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        HashSet<Movie> hashMovies = new HashSet<Movie>();
        TreeMap<Actor, HashSet<Movie>> treeMaps = new TreeMap<Actor, HashSet<Movie>>();
        Movie m;
        Actor a = null;
        Scanner scanner = new Scanner(new File("movies.txt"));
        while (scanner.hasNext()) {
            String lastName = scanner.nextLine();
            String firstName = scanner.nextLine();
            a = new Actor(lastName, firstName);
            if (!treeMaps.containsKey(a)) {
                treeMaps.put(a, new HashSet<Movie>());
            }
            String movieName = scanner.nextLine();
            String directorName = scanner.nextLine();
            Double budget = scanner.nextDouble();
            int runTime = scanner.nextInt();
            scanner.nextLine();
            String producerName = scanner.nextLine();
            String[] producerArray = producerName.split(",");
            m = new Movie(movieName, directorName, budget, runTime, producerArray);
            HashSet<Movie> m1 = new HashSet<>();
            if (treeMaps.get(a) == null) {
                m1.add(m);
                hashMovies = m1;
                treeMaps.put(a, m1);
            } else {
                hashMovies = treeMaps.get(a);
                hashMovies.add(m);
                treeMaps.put(a, hashMovies);
            }
        }
        System.out.println("Print the key and value pair using for loop:");
        for (Map.Entry<Actor, HashSet<Movie>> entry : treeMaps.entrySet()) {
            System.out.println(entry.getKey() + "; Movie Details: " + entry.getValue());
        }
        System.out.println("");
        System.out.println("*************************************************");
        System.out.println("Print the TreeMap:");
        System.out.println(treeMaps);
        System.out.println("");
        System.out.println("*************************************************");
    }
}


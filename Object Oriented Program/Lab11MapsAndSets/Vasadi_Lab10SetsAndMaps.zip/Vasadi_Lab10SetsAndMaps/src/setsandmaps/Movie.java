/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package setsandmaps;

/**
 *
 * @author Avinash Vasadi
 */
public class Movie {

    private String nameOfTheMovie;
    private String directorOfTheMovie;
    private double budgetOfTheMovie;
    private int lengthOfTheMovie;
    private String producerOfTheMovie[];

    /**
     * It defines the 5 Arguments Constructor
     *
     * @param nameOfTheMovie
     * @param directorOfTheMovie
     * @param budgetOfTheMovie
     * @param lengthOfTheMovie
     * @param producerOfTheMovie
     */
    public Movie(String nameOfTheMovie, String directorOfTheMovie, double budgetOfTheMovie, int lengthOfTheMovie, String producerOfTheMovie[]) {
        this.nameOfTheMovie = nameOfTheMovie;
        this.directorOfTheMovie = directorOfTheMovie;
        this.budgetOfTheMovie = budgetOfTheMovie;
        this.lengthOfTheMovie = lengthOfTheMovie;
        this.producerOfTheMovie = producerOfTheMovie;
    }

    /**
     * Name of the movie
     *
     * @return : It returns the name of the movie
     */
    public String getNameOfTheMovie() {
        return nameOfTheMovie;
    }

    /**
     * Director name
     *
     * @return : It returns the director name
     */
    public String getDirectorOfTheMovie() {
        return directorOfTheMovie;
    }

    /**
     * Budget of the movie
     *
     * @return : It returns the budget of the movie
     */
    public double getBudgetOfTheMovie() {
        return budgetOfTheMovie;
    }

    /**
     * Length of the movie in minutes
     *
     * @return : It returns the length of the movie in minutes
     */
    public int getLengthOfTheMovie() {
        return lengthOfTheMovie;
    }

    /**
     * Producer of the movie
     *
     * @return : It returns the producer of the movie
     */
    public String[] getProducerOfTheMovie() {
        return producerOfTheMovie;
    }

    /**
     * Sets the name of the movie
     *
     * @param nameOfTheMovie
     */
    public void setNameOfTheMovie(String nameOfTheMovie) {
        this.nameOfTheMovie = nameOfTheMovie;
    }

    /**
     * Sets the name of the director
     *
     * @param directorOfTheMovie
     */
    public void setDirectorOfTheMovie(String directorOfTheMovie) {
        this.directorOfTheMovie = directorOfTheMovie;
    }

    /**
     * Sets the budget of the movie
     *
     * @param budgetOfTheMovie
     */
    public void setBudgetOfTheMovie(double budgetOfTheMovie) {
        this.budgetOfTheMovie = budgetOfTheMovie;
    }

    /**
     * Sets the length of the movie
     *
     * @param lengthOfTheMovie
     */
    public void setLengthOfTheMovie(int lengthOfTheMovie) {
        this.lengthOfTheMovie = lengthOfTheMovie;
    }

    /**
     * Sets the producer of the movie
     *
     * @param producerOfTheMovie
     */
    public void setProducerOfTheMovie(String[] producerOfTheMovie) {
        this.producerOfTheMovie = producerOfTheMovie;
    }

    /**
     * Returns the string in required format
     *
     * @return : It returns the string in required format
     */
    @Override
    public String toString() {
        String result1 = String.format("Name: %s, Director: %s, " + "Budget: $%3.2f million, Length: %2d mins, Producer(s): ", nameOfTheMovie, directorOfTheMovie, budgetOfTheMovie, lengthOfTheMovie);
        for (String producer : producerOfTheMovie) {
            result1 += producer + ",";
        }
        return result1.substring(0, result1.length() - 1);
    }
}


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package setsandmaps;

/**
 *
 * @author Avinash Vasadi
 */
public class Actor implements Comparable<Actor> {

    private String lastName;
    private String firstName;

    /**
     * This is Two argument constructor
     *
     * @param lastName : defines last name of the actor
     * @param firstName : defines first name of the actor
     */
    public Actor(String lastName, String firstName) {
        this.lastName = lastName;
        this.firstName = firstName;
    }

    /**
     * Last name of the actor
     *
     * @return : It returns the last name of the actor
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Fist name of the actor
     *
     * @return : It returns the first name of the actor
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the last name of the actor
     *
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Sets the first name of the actor
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * String in the required format
     *
     * @return : s It returns the string in the required format
     */
    @Override
    public String toString() {
        return "Actor Name: " + String.format("%s,%s", lastName, firstName);
    }

    /**
     * Compares the last names of the actors
     *
     * @param o
     * @return : It returns the an integer based on the compared result
     */
    @Override
    public int compareTo(Actor o) {
        return lastName.compareTo(o.lastName);
    }
}


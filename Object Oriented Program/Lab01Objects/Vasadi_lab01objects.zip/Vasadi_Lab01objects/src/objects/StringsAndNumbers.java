/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objects;

import java.util.Random;

/**
 *
 * @author S528770
 */
public class StringsAndNumbers {
 public static void main(String[] args)   
 {
     //Declaring and Intializing strings//
     String string1 = "   Welcome";
     String string2 = "   to  ";
     String string3 = "Computer";
     String string4 = " Science     ";
     String string5 = " and ";
     String string6 = "  Information    ";
     String string7 = "Systems   ";
     
     //Concatenating strings and Printing the Length of String//
     String string8=string1.concat(string2).concat(string3).concat(string4).concat(string5).concat(string6).concat(string7);
     System.out.println( "The length of the Concatenated string is:" + string8.length());
     
    //Removing the Preceding and Trailing Spaces & Printing the Length of the resultant String//
     String string9 = string4.trim();
     System.out.println("Length of the trimmed string is:"+string9.length());
     
     //Printing the Index value of e of the string science//
     int temp=string8.substring(string8.indexOf("Science"),string8.indexOf("Science")+"Science".length()).indexOf("e");
     System.out.println("Index of first e in science is:"+temp);
     
     //Declaring & Intialising the given string and Printing the required result //
     String given = "rnururrunngisnnurun";
     System.out.println("First occurence of word run is:"+given.indexOf("run"));
     
     //Extracting the strings and concatenating with word and printing the resulting//
     String string10 = given.substring(given.indexOf("run"),given.indexOf("run")+"run".length()).concat(given.substring(given.indexOf("is"),given.indexOf("is")+"is".length()));
     String string11="fun";
     System.out.println(string10.concat(string11));
     
     //Declaring and Intializing with given strings and values//
     int myValue1,myValue2;
     myValue1 = 4;
     myValue2 = 6;
     
     //Calculating myValue1 raised to the power of myValue2 and Printing the result//
     double Value3 = java.lang.Math.pow(myValue1,myValue2);
     System.out.println(Value3);
     
     //Declaring and Intializing values and printing the required outputs//
     double myNumber;
     myNumber = 26.30;
     System.out.println("Square root of the number is :"+Math.sqrt(myNumber));
     System.out.println("Ceil value is:"+Math.ceil(myNumber));
     System.out.println("Floor value is:"+Math.floor(myNumber));
     //Declaring and Intializing values and printing the rounded results of the sin and tangent values//
     double myNumber1 = 30;
     double myNumber2 = 75;
     System.out.println(Math.round(Math.sin(myNumber1)));
     System.out.println(Math.round(Math.sin(myNumber2)));
     System.out.println(Math.round(Math.tan(myNumber1)));
     System.out.println(Math.round(Math.tan(myNumber2)));
     System.out.println(Math.ceil(Math.sinh(Math.sqrt(Math.pow(5,2)+(4*3*3)+2)/(3*2))));
     System.out.println("\n");
     
     //Creating an instance of the random class//
     Random r = new Random(10L);
     System.out.println("First Random value:"+r.nextInt(200));
     System.out.println("Second Random value:"+r.nextInt(200));
     System.out.println("Third Random value:"+r.nextInt(200));
     System.out.println("Fourth Random value:"+r.nextInt(200));
     System.out.println("Fifth Random value:"+r.nextInt(200));
     System.out.println("Sixth Random value:"+r.nextInt(200));
     System.out.println("Seventh Random value:"+r.nextInt(200));
     System.out.println("\nYES, Everytime getting the same result after running the code for 2 or 3 times. ");
     Random r1 = new Random();
     System.out.println("\nFirst Random value:"+r1.nextInt(200));
     System.out.println("Second Random value:"+r1.nextInt(200));
     System.out.println("Third Random value:"+r1.nextInt(200));
     System.out.println("Fourth Random value:"+r1.nextInt(200));
     System.out.println("Fifth Random value:"+r1.nextInt(200));
     System.out.println("Sixth Random value:"+r1.nextInt(200));
     System.out.println("Seventh Random value:"+r1.nextInt(200));
     System.out.println("\nNO, without seed value getting different values randomly");
     System.out.println("\nThe difference between both is on providing seed value it gives the same random values for several runs but without seed value it generates different values at every run.");
       
 }
 
}

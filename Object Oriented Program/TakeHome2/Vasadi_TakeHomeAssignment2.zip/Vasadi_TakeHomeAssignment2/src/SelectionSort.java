
import java.util.Arrays;

/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section <Your section number>
*
* Due date: 5pm, Friday, March 17, 2017.
*
* @author Avinash Vasadi
*
*/

/**
 *
 * @author Avinash Vasadi
 */
public class SelectionSort {

    private long InitialTimeSS;
    private long FinalTimeSS;

    /**
     * This method performs the Selection Sorting. Find the smallest element,
     * and put it to the first position. Find the next smallest element, and put
     * it to the second position. Repeat until all elements are in the right
     * positions.
     *
     * @param array It takes the array as an argument
     * @return integer swaps count
     */
    public int SelectionSort(int[] array) {
        int swaps = 0, minimumIndex = 0;
        InitialTimeSS = System.currentTimeMillis();
        for (int i = 0; i < array.length; i++) {
            int minimumValue = array[i];
            minimumIndex = i;
            for (int j = i; j < array.length; j++) {
                if (array[j] < minimumValue) {
                    minimumValue = array[j];
                    minimumIndex = j;
                }
            }
            if (minimumValue < array[i]) {
                int temporayValue = array[i];
                array[i] = array[minimumIndex];
                array[minimumIndex] = temporayValue;
                swaps++;
            }
        }

        FinalTimeSS = System.currentTimeMillis();
        return swaps;
    }

    /**
     * This method calculates the time to perform sorting by taking the
     * difference of final time and initial time.
     *
     * @return long It returns the time taken to perform sorting.
     */
    public long TimeInSelection() {
        return FinalTimeSS - InitialTimeSS;
    }
}

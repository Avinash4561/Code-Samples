
import java.util.Arrays;

/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section <Your section number>
*
* Due date: 5pm, Friday, March 17, 2017.
*
* @author Avinash Vasadi
*
*/

/**
 *
 * @author Avinash Vasadi
 */
public class InsertionSort {

    private long InitialTimeIS;
    private long FinalTimeIS;

    /**
     * This method performs the Insertion Sorting. Take the first element as a
     * sorted sub-array. Insert the second element into the sorted sub-array
     * (shift elements if needed). Insert the third element into the sorted
     * sub-array. Repeat until all elements are inserted.
     *
     * @param array It takes the array as an argument.
     * @return integer swaps count
     */
    public int InsertionSort(int[] array) {

        int i, j, keyValue, temporaryValue, swaps = 0;

        InitialTimeIS = System.currentTimeMillis();
        for (i = 1; i < array.length; i++) {
            keyValue = array[i];
            j = i - 1;
            while (j >= 0 && keyValue < array[j]) {
                temporaryValue = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temporaryValue;
                j--;
                swaps++;
            }
        }
        FinalTimeIS = System.currentTimeMillis();
        //  System.out.println(Arrays.toString(array));
        return swaps;
    }

    /**
     * This method calculates the time to perform sorting by taking the
     * difference of final time and initial time.
     *
     * @return long It holds Time to perform sorting.
     */
    public long TimeInInsertion() {
        return FinalTimeIS - InitialTimeIS;
    }

}


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section <Your section number>
*
* Due date: 5pm, Friday, March 17, 2017.
*
* @author Avinash Vasadi
*
*/

/**
 *
 * @author Avinash Vasadi
 */
public class Driver {

    /**
     * This is the main method to perform three sorting techniques on the three
     * different arrays.
     *
     * @param args the command line arguments it
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int[] inOrder = new int[1000];
        for (int i = inOrder.length - 1; i >= 0; i--) {
            inOrder[i] = i + 1;
        }

        SelectionSort s = new SelectionSort();
        int orderSwapsInSelection = s.SelectionSort(inOrder);
        long orderTimeInSelection = s.TimeInSelection();

        InsertionSort i = new InsertionSort();
        int orderSwapsInInsertion = i.InsertionSort(inOrder);
        long orderTimeInInsertion = i.TimeInInsertion();

        BubbleSort b = new BubbleSort();
        int orderSwapsInBubble = b.BubbleSort(inOrder);
        long orderTimeInBubble = b.TimeInBubble();

        System.out.println("\t\t" + "Selection Sort\t" + "Insertion Sort\t" + "Bubble Sort\t");
        System.out.println("Data\t\ttime\tswaps\ttime\tswaps\ttime\tswaps");
        System.out.println("In order\t" + orderTimeInSelection + "\t" + orderSwapsInSelection + "\t"
                + orderTimeInInsertion + "\t" + orderSwapsInInsertion + "\t"
                + orderTimeInBubble + "\t" + orderSwapsInBubble);

        int[] reverseOrder1 = new int[1000];
        for (int j = 0; j < reverseOrder1.length; j++) {
            reverseOrder1[j] = 1000 - j;
        }

        int[] reverseOrder2 = reverseOrder1.clone();
        int[] reverseOrder3 = reverseOrder1.clone();

        int reverseSwapsInSelection = s.SelectionSort(reverseOrder1);
        long reverseTimeInSelection = s.TimeInSelection();

        int reverseSwapsInInsertion = i.InsertionSort(reverseOrder2);
        long reverseTimeInInsertion = i.TimeInInsertion();

        int reverseSwapsInBubble = b.BubbleSort(reverseOrder3);
        long reverseTimeInBubble = b.TimeInBubble();

        System.out.println("Reverse order\t" + reverseTimeInSelection + "\t" + reverseSwapsInSelection + "\t"
                + reverseTimeInInsertion + "\t" + reverseSwapsInInsertion + "\t"
                + reverseTimeInBubble + "\t" + reverseSwapsInBubble);

        int[] randomOrder1 = new int[1000];
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        for (int k = 0; k < 1000; k++) {
            numbers.add(k + 1);
        }
        Collections.shuffle(numbers);

        int index = 0;
        for (int values : numbers) {
            randomOrder1[index] = values;
            index++;
        }

        int[] randomOrder2 = new int[1000];
        randomOrder2 = randomOrder1.clone();
        int[] randomOrder3 = new int[1000];
        randomOrder3 = randomOrder1.clone();

        int randomSwapsInSelection = s.SelectionSort(randomOrder1);
        long randomTimeInSelection = s.TimeInSelection();

        int randomSwapsInInsertion = i.InsertionSort(randomOrder2);
        long randomTimeInInsertion = i.TimeInInsertion();

        int randomSwapsInBubble = b.BubbleSort(randomOrder3);
        long randomTimeInBubble = b.TimeInBubble();

        System.out.println("Random order\t" + randomTimeInSelection + "\t" + randomSwapsInSelection + "\t"
                + randomTimeInInsertion + "\t" + randomSwapsInInsertion + "\t"
                + randomTimeInBubble + "\t" + randomSwapsInBubble);
    }

}

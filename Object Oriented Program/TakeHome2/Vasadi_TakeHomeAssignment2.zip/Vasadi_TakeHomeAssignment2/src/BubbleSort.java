
import java.util.Arrays;

/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section <Your section number>
*
* Due date: 5pm, Friday, March 17, 2017.
*
* @author Avinash Vasadi
*
*/

/**
 *
 * @author Avinash Vasadi
 */
public class BubbleSort {

    private long InitialTimeBS;
    private long FinalTimeBS;

    /**
     *
     * This method performs the bubble sorting. Scan the array, swapping
     * adjacent pair of elements if they are not in relative order. This bubbles
     * up the largest element to the end. Scan the array again, bubbling up the
     * second largest element. Repeat until all elements are in order.
     *
     * @param array It takes an array as an argument
     * @return integer swaps count
     */
    public int BubbleSort(int[] array) {
        // long initialTime = System.currentTimeMillis();
        int swaps = 0;
        //    System.out.println(Arrays.toString(array));
        InitialTimeBS = System.currentTimeMillis();
        for (int i = 0; i < array.length - 1; i++) {
            for (int j = 0; j < array.length - 1 - i; j++) {
                if (array[j] > array[j + 1]) {
                    int temporayValue = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temporayValue;
                    swaps++;
                    //  System.out.println(swaps);
                }
            }
        }
        FinalTimeBS = System.currentTimeMillis();
        return swaps;
    }

    /**
     * This method calculates the time to perform sorting by taking the
     * difference of final time and initial time.
     *
     * @return long Time taken.
     */
    public long TimeInBubble() {
        return FinalTimeBS - InitialTimeBS;
    }

}

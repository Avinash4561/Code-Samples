
import java.util.Scanner;
import java.util.*;

/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section 01
*
* Due date: 5 p.m, Friday, April 14, 2017.
*
* @author Avinash Vasadi
*/
public class Checker {

    public static String readPlayerInput(Scanner reader) {

        System.out.println("Place Your Move: ");
        String input = reader.nextLine();

        return input.toUpperCase();
    }

    public static int winner(Node gameNode) {
        int blackDails = 0;
        int whiteDails = 0;

        for (int i = 0; i < 8; i++) {

            for (int j = 0; j < 8; j++) {
                if (gameNode.state.board.board[i][j] == 1) {
                    blackDails++;
                } else {
                    whiteDails++;
                }
            }
        }

        if (blackDails > whiteDails) {
            return 1;
        } else if (blackDails == whiteDails) {
            return 9001;
        } else {
            return 2;
        }

    }

    public static int SEF(Node n) {
        int value = 0;

        if (n.state.piece == 2) 
        {
            value += n.state.numberOfFlanks;
            value += n.state.numberOfDirections;
            if (n.state.hasCorner) {
                value += 3;
            }
        }
        if (n.state.piece == 1) {
            value -= n.state.numberOfFlanks;
            value -= n.state.numberOfDirections;
            if (n.state.hasCorner) {
                value -= 3;
            }
        }

        return value;
    }

    public static boolean gameOver(boolean jumpPlayer1, boolean jumpPlayer2) {
        if (jumpPlayer1 && jumpPlayer2) {
            return true;
        } else {
            return false;
        }
    }

}

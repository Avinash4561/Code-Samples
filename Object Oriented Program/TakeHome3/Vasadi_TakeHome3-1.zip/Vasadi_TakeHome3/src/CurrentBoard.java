
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.*;

/**
 * I certify that all code in this file is my own work. This code is submitted
 * as the solution to Assignment 1 in CSIS44542 Object-Oriented Programming,
 * 2017, section 01
 *
 * Due date: 5 p.m, Friday, April 14, 2017.
 *
 * @author Avinash Vasadi
 */
public class CurrentBoard {

    public Board board = new Board();
    public List< Node> children = new ArrayList< Node>();
    public HashMap< String, Node> moveAndChildNode = new HashMap< String, Node>();
    public int SEF;
    public int piece;
    public int player;
    public int numberOfFlanks = 0;
    public boolean hasCorner = false;
    public int numberOfDirections = 0;
    public boolean isroot;
    final String NORTH = "NORTH";
    final String NORTHEAST = "NORTHEAST";
    final String NORTHWEST = "NORTHWEST";
    final String EAST = "EAST";
    final String WEST = "WEST";
    final String SOUTH = "SOUTH";
    final String SOUTHEAST = "SOUTHEAST";
    final String SOUTHWEST = "SOUTHWEST";

    public void printBoard() {

        System.out.println("    0   1   2   3   4   5   6   7 ");
        for (int i = 0; i < 8; i++) {
            System.out.print("  +----+---+---+---+---+---+---+---+\n");
            char columnChar = 'A';
            switch (i) {
                case 0:
                    columnChar = 'A';
                    break;
                case 1:
                    columnChar = 'B';
                    break;
                case 2:
                    columnChar = 'C';
                    break;
                case 3:
                    columnChar = 'D';
                    break;
                case 4:
                    columnChar = 'E';
                    break;
                case 5:
                    columnChar = 'F';
                    break;
                case 6:
                    columnChar = 'G';
                    break;
                case 7:
                    columnChar = 'H';
                    break;
            }

            System.out.print(columnChar + " | ");

            for (int j = 0; j < 8; j++) {
                if (board.board[i][j] != 0) {
                    System.out.print(" " + board.board[i][j] + " |");
                } else {
                    System.out.print(" " + " " + " |");
                }
            }

            System.out.println("");
        }

        System.out.print("  +----+---+---+---+---+---+---+---+\n");
    }

    public CurrentBoard(int piece, int player) {

        this.SEF = 1;
        this.piece = piece;
        this.player = player;
        this.isroot = true;

        if (isroot) {
            this.board.board[3][3] = 2;
            this.board.board[3][4] = 1;
            this.board.board[4][3] = 1;
            this.board.board[4][4] = 2;

        }

    }

    public CurrentBoard(CurrentBoard s) {
        int[][] newboard = new int[8][8];

        for (int i = 0; i < newboard.length; i++) {
            newboard[i] = Arrays.copyOf(s.board.board[i], s.board.board[i].length);
        }

        this.board = new Board(newboard);
        this.SEF = s.SEF;
        this.isroot = false;
    }

    public void makeMove(String move) {

        int row = 0;
        int column = Integer.parseInt(Character.toString(move.charAt(1)));

        switch (move.charAt(0)) {
            case 'A':
                row = 0;
                break;
            case 'B':
                row = 1;
                break;
            case 'C':
                row = 2;
                break;
            case 'D':
                row = 3;
                break;
            case 'E':
                row = 4;
                break;
            case 'F':
                row = 5;
                break;
            case 'G':
                row = 6;
                break;
            case 'H':
                row = 7;
                break;
        }

        evaluateMove(row, column, false);

    }

    public int[] readPlayerInput(Scanner reader) {

        char number;
        int[] usersPos = new int[2];
        System.out.println("Place Your Move: ");
        String input = reader.nextLine();

        char letter = input.charAt(0);

        int row = 0;
        int column = Character.getNumericValue(input.charAt(1));

        switch (letter) {
            case 'A':
                row = 0;
                break;
            case 'B':
                row = 1;
                break;
            case 'C':
                row = 2;
                break;
            case 'D':
                row = 3;
                break;
            case 'E':
                row = 4;
                break;
            case 'F':
                row = 5;
                break;
            case 'G':
                row = 6;
                break;
            case 'H':
                row = 7;
                break;
        }

        usersPos[0] = row;
        usersPos[1] = column;

        return usersPos;
    }

    public List< Object> checkAvailableMoves() {
        char columnChar = ' ';
        List< String> availableMoves = new ArrayList< String>();
        List< Object> isValidMoveAndAvailableMoves = new ArrayList< Object>();

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {

                if (board.board[i][j] == 0 && evaluateMove(i, j, true)) {

                    switch (i) {
                        case 0:
                            columnChar = 'A';
                            break;
                        case 1:
                            columnChar = 'B';
                            break;
                        case 2:
                            columnChar = 'C';
                            break;
                        case 3:
                            columnChar = 'D';
                            break;
                        case 4:
                            columnChar = 'E';
                            break;
                        case 5:
                            columnChar = 'F';
                            break;
                        case 6:
                            columnChar = 'G';
                            break;
                        case 7:
                            columnChar = 'H';
                            break;
                    }

                    String column = Integer.toString(j);

                    String position = columnChar + column;
                    availableMoves.add(position);
                }

            }
        }

        if (availableMoves.size() >= 1) {

            isValidMoveAndAvailableMoves.add(true);
            isValidMoveAndAvailableMoves.add(availableMoves);

            return isValidMoveAndAvailableMoves;
        }

        isValidMoveAndAvailableMoves.add(false);

        return isValidMoveAndAvailableMoves;

    }

    public boolean evaluateMove(int row, int column, boolean checkingForValidMove) {

        List boolList = new ArrayList< Boolean>();
        boolean continueSearching = false;
        int target = (piece == 1) ? 2 : 1;
        boolean isThisAValidMove = true;

        if (row != 0) {
            if ((board.board[row - 1][column] != 0) && (board.board[row - 1][column] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                continueSearching = true;
            }

            if (continueSearching) {
                if (checkCardinalDirection((row - 1), column, target, NORTH, checkingForValidMove)) {
                    this.numberOfDirections++;
                    boolList.add(true);
                }
            }

        }

        continueSearching = false;

        if (row != 0) {
            if (column != 7) {
                if ((board.board[row - 1][column + 1] != 0) && (board.board[row - 1][column + 1] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                    continueSearching = true;
                }

                if (continueSearching) {
                    if (checkDiagonalDirection(row - 1, column + 1, target, NORTHEAST, checkingForValidMove)) {
                        this.numberOfDirections++;
                        boolList.add(true);
                    }
                }
            }
        }

        continueSearching = false;

        if (row != 0) {
            if (column != 0) {
                if ((board.board[row - 1][column - 1] != 0) && (board.board[row - 1][column - 1] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                    continueSearching = true;
                }

                if (continueSearching) {
                    if (checkDiagonalDirection(row - 1, column - 1, target, NORTHWEST, checkingForValidMove)) {
                        boolList.add(true);
                        this.numberOfDirections++;
                    }
                }
            }
        }

        continueSearching = false;

        if (column != 7) {

            if ((board.board[row][column + 1] != 0) && (board.board[row][column + 1] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                continueSearching = true;
            }

            if (continueSearching) {
                if (checkCardinalDirection(row, (column + 1), target, EAST, checkingForValidMove)) {
                    boolList.add(true);
                    this.numberOfDirections++;
                }
            }

        }

        continueSearching = false;

        if (column != 0) {

            if ((board.board[row][column - 1] != 0) && (board.board[row][column - 1] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                continueSearching = true;
            }

            if (continueSearching) {
                if (checkCardinalDirection(row, (column - 1), target, WEST, checkingForValidMove)) {
                    boolList.add(true);
                    this.numberOfDirections++;
                }
            }

        }

        continueSearching = false;

        if (row != 7) {

            if ((board.board[row + 1][column] != 0) && (board.board[row + 1][column] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                continueSearching = true;
            }

            if (continueSearching) {
                if (checkCardinalDirection(row + 1, column, target, SOUTH, checkingForValidMove)) {
                    boolList.add(true);
                    this.numberOfDirections++;
                }
            }

        }

        continueSearching = false;

        if (row != 7) {
            if (column != 7) {
                if ((board.board[row + 1][column + 1] != 0) && (board.board[row + 1][column + 1] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                    continueSearching = true;
                }

                if (continueSearching) {
                    if (checkDiagonalDirection(row + 1, column + 1, target, SOUTHEAST, checkingForValidMove)) {
                        boolList.add(true);
                        this.numberOfDirections++;
                    }
                }
            }
        }

        continueSearching = false;

        if (row != 7) {

            if (column != 0) {
                if ((board.board[row + 1][column - 1] != 0) && (board.board[row + 1][column - 1] != piece)) { //if adjacent space not  empty or space not  occupied by friendly piece
                    continueSearching = true;

                }

                if (continueSearching) {
                    if (checkDiagonalDirection(row + 1, column - 1, target, SOUTHWEST, checkingForValidMove)) {
                        boolList.add(true);
                        this.numberOfDirections++;
                    }
                }
            }
        }

        if (boolList.size() == 0) {
            isThisAValidMove = false;
        } else {

            if ((row == 0 && column == 0) || (row == 0 && column == 7) || (row == 7 && column == 0) || (row == 7 && column == 7)) {
                hasCorner = true;
            }

        }

        if (!checkingForValidMove) {
            // Everything went fine. Now place the piece onto the board
            this.board.board[row][column] = piece;

        }

        return isThisAValidMove;
    }

    boolean checkCardinalDirection(int row, int column, int target, String direction, boolean checkingForValidMove) {
        int piece = (target == 1) ? 2 : 1;

        if (board.board[row][column] == piece) {
            return true;
        } else if (direction == NORTH && row == 0) {
            return false;
        } else if (direction == EAST && column == 7) {
            return false;
        } else if (direction == WEST && column == 0) {
            return false;
        } else if (direction == SOUTH && row == 7) {
            return false;
        }

        if (direction == NORTH) {
            if (checkCardinalDirection(row - 1, column, target, NORTH, checkingForValidMove) == true) {
                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;
                }
                return true;
            }
        } else if (direction == EAST) {
            if (checkCardinalDirection(row, column + 1, target, EAST, checkingForValidMove) == true) {
                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;

                }
                return true;
            }
        } else if (direction == WEST) {
            if (checkCardinalDirection(row, column - 1, target, WEST, checkingForValidMove) == true) {
                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;

                }
                return true;
            }
        } else if (direction == SOUTH) {
            if (checkCardinalDirection(row + 1, column, target, SOUTH, checkingForValidMove) == true) {
                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;
                }
                return true;
            }
        }

        return false;
    }

    boolean checkDiagonalDirection(int row, int column, int target, String direction, boolean checkingForValidMove) {

        int piece = (target == 1) ? 2 : 1;

        if (board.board[row][column] == piece) {

            return true;
        } else if (direction == NORTHEAST && (row == 0 || column == 7)) {

            return false;
        } else if (direction == NORTHWEST && (row == 0 || column == 0)) {

            return false;
        } else if (direction == SOUTHEAST && (row == 7 || column == 7)) {

            return false;
        } else if (direction == SOUTHWEST && (row == 7 || column == 0)) {

            return false;
        }

        if (direction == NORTHEAST) {

            if (checkDiagonalDirection(row - 1, column + 1, target, NORTHEAST, checkingForValidMove) == true) {

                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;
                }
                return true;
            }
        } else if (direction == NORTHWEST) {

            if (checkDiagonalDirection(row - 1, column - 1, target, NORTHWEST, checkingForValidMove) == true) {

                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;
                }
                return true;
            }
        } else if (direction == SOUTHEAST) {

            if (checkDiagonalDirection(row + 1, column + 1, target, SOUTHEAST, checkingForValidMove) == true) {

                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;
                }
                return true;
            }
        } else if (direction == SOUTHWEST) {

            if (checkDiagonalDirection(row + 1, column - 1, target, SOUTHWEST, checkingForValidMove) == true) {

                if (!checkingForValidMove) {

                    board.board[row][column] = piece;
                    this.numberOfFlanks++;
                }

                return true;
            }

        }

        return false;
    }
}

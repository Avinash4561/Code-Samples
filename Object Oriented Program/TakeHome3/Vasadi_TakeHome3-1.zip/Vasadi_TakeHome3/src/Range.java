
/**
 * I certify that all code in this file is my own work.
 * This code is submitted as the solution to Assignment 1
 * in CSIS44542 Object-Oriented Programming, 2017, section 01
 *
 * Due date: 5 p.m, Friday, April 14, 2017.
 *
 * @author Avinash Vasadi
 */

class Range extends Thread {

    int currentLevel = 0;
    int currentDepth = 0;
    public static Checker evaluator = new Checker();
    Node currentNode;

    public Range(int inputLevel, int inputDepth, Node inputNode) {
        this.currentLevel = inputLevel;
        this.currentDepth = inputDepth;
        this.currentNode = inputNode;
    }

    public static int minimax(Node node, int level, int depth) {
        int RVal = 0;
        int value = 0;

        if (level == depth) {
            node.SEF = evaluator.SEF(node);

            return evaluator.SEF(node);
        } else if (level % 2 == 0) {

            if (node.level == 0 && node.neighbour == 1) {

            }
            value = Integer.MIN_VALUE;
            for (Node n : node.state.children) {
                RVal = minimax(n, level + 1, depth);

                if (RVal > value) {

                    value = RVal;
                    node.SEF = value;
                }
            }
        } else {
            value = Integer.MAX_VALUE;
            for (Node n : node.state.children) {
                RVal = minimax(n, level + 1, depth);

                if (RVal < value) {
                    value = RVal;
                    node.SEF = value;
                }
            }
        }

        return value;
    }

    public void run() {
        minimax(this.currentNode, this.currentLevel, this.currentDepth);
    }
}

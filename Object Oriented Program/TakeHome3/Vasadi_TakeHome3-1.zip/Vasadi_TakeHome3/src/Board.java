/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section 01
*
* Due date: 5 p.m, Friday, April 14, 2017.
*
* @author Avinash Vasadi
*/
public class Board {

    int[][] board = new int[8][8];

    public Board(Board b) {
        this.board = b.board;
    }

    public Board(int[][] newBoard) {
        this.board = newBoard;
    }

    public Board() {
    }

}

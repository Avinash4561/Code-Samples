
/**
 * I certify that all code in this file is my own work.
 * This code is submitted as the solution to Assignment 1
 * in CSIS44542 Object-Oriented Programming, 2017, section 01
 *
 * Due date: 5 p.m, Friday, April 14, 2017.
 *
 * @author Avinash Vasadi
 */

public class Node {

    public int level;
    public int neighbour;
    public CurrentBoard state;
    public int SEF = 0;

    Node(CurrentBoard s) {
        this.state = s;

        if (this.state.isroot) {
            this.level = 0;
            this.neighbour = 1;
        }
    }
}

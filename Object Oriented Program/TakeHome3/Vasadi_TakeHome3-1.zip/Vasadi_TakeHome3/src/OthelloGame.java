
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * I certify that all code in this file is my own work. This code is submitted
 * as the solution to Assignment 1 in CSIS44542 Object-Oriented Programming,
 * 2017, section 01
 *
 * Due date: 5 p.m, Friday, April 14, 2017.
 *
 * @author Avinash Vasadi
 */
public class OthelloGame {

    public static int maxDepth = 3;
    public static boolean skipPlayer1 = false;
    public static boolean skipPlayer2 = false;
    public static Checker evaluator = new Checker();

    public static void main(String[] args) {
        CurrentBoard initialState = new CurrentBoard(2, 2);
        Node initialNode = new Node(initialState);

        List< Node> initialMove = new ArrayList< Node>();
        List< String> initialStatesMoves = new ArrayList< String>();
        initialMove.add(initialNode);

        buildGameTree(initialMove, maxDepth);

        initialMinimax(initialNode, 0, maxDepth);

        Node currentPly = initialNode;
        int nextCuttOffLevel = 0;
        Scanner reader = new Scanner(System.in);

        System.out.println("Play Othello Game\n");
        currentPly.state.printBoard();

        while (!(evaluator.gameOver(skipPlayer1, skipPlayer2))) {

            List< Object> availableMoves = new ArrayList< Object>();
            availableMoves = currentPly.state.checkAvailableMoves();

            if (maxDepth == 0) {

                maxDepth = 2;
                List< Node> newMove = new ArrayList< Node>();
                newMove.add(currentPly);

                buildGameTree(newMove, maxDepth);

                Range t1 = new Range(0, maxDepth, currentPly);
                t1.start();
                try {
                    t1.join();
                } catch (InterruptedException e) {

                }

            }

            if (maxDepth % 2 != 0) {

                if ((boolean) availableMoves.get(0) == false) {

                    skipPlayer1 = true;
                } else {

                    skipPlayer1 = false;

                    System.out.print("Available moves for you: ");
                    for (String move : (ArrayList< String>) availableMoves.get(1)) {
                        System.out.print(move + ", ");
                    }
                    System.out.println("");

                    String playerInput = evaluator.readPlayerInput(reader);

                    Node move = currentPly.state.moveAndChildNode.get(playerInput);

                    currentPly = move;

                    System.out.println("PRINTED SECOND BOARD");
                    currentPly.state.printBoard();
                }

            } else {

                System.out.println("AI gives you stern look. à² â•­â•®à² ");

                if ((boolean) availableMoves.get(0) == false) {

                    skipPlayer2 = true;
                } else {
                    skipPlayer2 = false;

                    String moveWithLowestSEF = "";
                    int lowestSEF = Integer.MAX_VALUE;

                    System.out.println("Computer Making Moves");
                    System.out.println("Number of moves available to AI: " + currentPly.state.moveAndChildNode.size());
                    for (Map.Entry< String, Node> entry : currentPly.state.moveAndChildNode.entrySet()) {
                        if (entry.getValue().SEF < lowestSEF) {
                            lowestSEF = entry.getValue().SEF;
                            moveWithLowestSEF = entry.getKey();
                        }
                    }

                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {

                    }

                    System.out.println("Computeer placed a move on " + moveWithLowestSEF);

                    Node move = currentPly.state.moveAndChildNode.get(moveWithLowestSEF);

                    currentPly = move;

                    currentPly.state.printBoard();
                }
            }

            maxDepth -= 1;
            nextCuttOffLevel++;

        }

        int winningValue = evaluator.winner(currentPly);

        if (winningValue == 1) {
            System.out.println("AI WINS!!!!");
        } else if (winningValue == 2) {
            System.out.println("YOU WIN!!!!");
        } else if (winningValue == 9001) {
            System.out.println("DRAW!!!!");
        }

    }

    public static int initialMinimax(Node node, int level, int depth) {
        int RVal = 0;
        int value = 0;

        if (level == depth) {
            node.SEF = evaluator.SEF(node);

            return evaluator.SEF(node);
        } else if (level % 2 == 0) {

            if (node.level == 0 && node.neighbour == 1) {

            }
            value = Integer.MIN_VALUE;
            for (Node n : node.state.children) {
                RVal = initialMinimax(n, level + 1, depth);

                if (RVal > value) {

                    value = RVal;
                    node.SEF = value;
                }
            }
        } else {
            value = Integer.MAX_VALUE;
            for (Node n : node.state.children) {
                RVal = initialMinimax(n, level + 1, depth);
                if (RVal < value) {
                    value = RVal;
                    node.SEF = value;
                }
            }
        }

        return value;
    }

    public static void printSEFVals(List< Node> nodeArray, int Depth) {
        if (Depth == 0) {
            for (Node n : nodeArray) {

            }

            return;
        }

        for (Node n : nodeArray) {

            printSEFVals(n.state.children, Depth - 1);
        }

    }

    public static void buildGameTree(List< Node> nodeArray, int Depth) {
        int piece = 0;
        int player = 0;

        if (Depth % 2 == 0) {
            piece = 1;
            player = 1;
        } else {
            piece = 2;
            player = 2;
        }

        if (Depth == 0) {

            return;
        }

        for (Node n : nodeArray) {

            n.state.player = player;
            n.state.piece = piece;

            if ((boolean) n.state.checkAvailableMoves().get(0) == false) {
                continue;
            }

            List< String> moves = (ArrayList< String>) n.state.checkAvailableMoves().get(1);

            int counter = 0;

            for (String move : moves) {

                counter += 1;

                CurrentBoard newState = new CurrentBoard(n.state);
                newState.player = player;
                newState.piece = piece;
                newState.makeMove(move);

                Node newNode = new Node(newState);
                newNode.level = n.level + 1;
                newNode.neighbour = counter;
                n.state.children.add(newNode);
                n.state.moveAndChildNode.put(move, newNode);
            }

            buildGameTree(n.state.children, Depth - 1);
        }
    }
}

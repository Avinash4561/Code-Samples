/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;

/**
 * I certify that all code in this file is my own work. This code is submitted
 * as the solution to Assignment 1 in CSIS44542 Object-Oriented Programming,
 * 2017, section 01
 *
 * Due date: 5pm, Friday, February 17, 2017.
 *
 * @author Avinash Vasadi
 */
public class FleschKincaid {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException It throws exception inputFileName
     * is not found
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

//Intialising Scanner and Reading the InputFileName from the user 
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter the name of the file containing ths passage of text: ");
        String inputFileName = input.next();
        File inputFile = new File(inputFileName);
//Checking Whether the user given InputFile Exists or Not. If exists reading the data from the file.
        if (inputFile.exists()) {
            Scanner File = new Scanner(inputFile);
            String Data = File.nextLine();
//Counting the Number of Sentences and Number of Words in the given data.
            double NumberOfWords = 1, NumberOfSentences = 1;
            for (int i = 0; i < Data.length(); i++) {
                if (Data.charAt(i) == ' ' && Data.charAt(i + 1) != ' ') {
                    NumberOfWords = NumberOfWords + 1;
                }
                if (Data.charAt(i) == '.') {
                    NumberOfSentences += 1;
                }
            }
//Counting the Number of Syllables in the given data.
            int indexValue = 0;
            double NumberOfSyllablesInAWord = 0, z = 0, n = 0.0;
            String word;
            do {
                double m = NumberOfSyllablesInAWord;
                if (z == NumberOfWords - 1) {
                    word = Data.substring(indexValue, (Data.length() - 1));
                } else {
                    word = Data.substring(indexValue, Data.indexOf(" ", indexValue));
                    indexValue = Data.indexOf(" ", indexValue) + 1;
                }
                for (int i = 0; i < word.length(); i++) {
                    word = word.toLowerCase();
                    if (word.charAt(i) == 'a' || word.charAt(i) == 'e' || word.charAt(i) == 'i' || word.charAt(i) == 'o' || word.charAt(i) == 'u' || word.charAt(i) == 'y') {
                        NumberOfSyllablesInAWord++;
                        if (i + 1 < word.length()) {
                            if (word.charAt(i + 1) == 'a' || word.charAt(i + 1) == 'e' || word.charAt(i + 1) == 'i' || word.charAt(i + 1) == 'o' || word.charAt(i + 1) == 'u' || word.charAt(i + 1) == 'y') {
                                NumberOfSyllablesInAWord--;
                                if (i == word.length() - 2 && word.charAt(i + 1) == 'e') {
                                    NumberOfSyllablesInAWord++;
                                }
                            }
                        }
                        if (word.charAt(i) == 'e' && (i == word.length() - 1)) {
                            NumberOfSyllablesInAWord--;
                        }
                    }
                    n = NumberOfSyllablesInAWord;
                }
                if (n - m == 0) {
                    NumberOfSyllablesInAWord++;
                }
                z++;
            } while (Data.indexOf(" ", indexValue) != -1 || z == NumberOfWords - 1);

//Calculating the ReadingEase and GradeLevel
            double ReadingEase, x, y, GradeLevel;
            x = NumberOfWords / (NumberOfSentences - 1);
            y = NumberOfSyllablesInAWord / NumberOfWords;
            ReadingEase = 206.835 - (1.015 * x) - (84.6 * y);
            GradeLevel = (0.39 * x) + (11.8 * y) - 15.59;
            
//Caluclating the School Level based on ReadingEase
            String SchoolLevel = "";
            if (ReadingEase <= 100.00 && ReadingEase > 90.00) {
                SchoolLevel = "5th grade";
            } else if (ReadingEase > 80.00 && ReadingEase <= 90.00) {
                SchoolLevel = "6th grade";
            } else if (ReadingEase > 70.00 && ReadingEase <= 80.00) {
                SchoolLevel = "7th grade";
            } else if (ReadingEase > 60.00 && ReadingEase <= 70.00) {
                SchoolLevel = "8th & 9th grade";
            } else if (ReadingEase > 50.00 && ReadingEase <= 60.00) {
                SchoolLevel = "10th to 12th grade";
            } else if (ReadingEase > 30.00 && ReadingEase <= 50.00) {
                SchoolLevel = "College";
            } else if (ReadingEase > 0.00 && ReadingEase <= 30.00) {
                SchoolLevel = "College Graduate";
            }
//Printing the Output as required
            System.out.println("The passage has the following scores:-\n\tFlesch reading ease:\t\t"
                    + String.format("%.1f", ReadingEase) + " (" + SchoolLevel + ")");
            System.out.println("\tFlesch-Kincaid grade level: \t" + String.format("%.1f", GradeLevel));
        } else {
            System.out.println("File not found.");
        }
    }

}

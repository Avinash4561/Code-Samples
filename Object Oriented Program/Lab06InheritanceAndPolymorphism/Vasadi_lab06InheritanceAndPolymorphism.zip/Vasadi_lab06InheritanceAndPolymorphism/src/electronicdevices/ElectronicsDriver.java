/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 * This the Driver class which contains the main method.
 *
 * @author Avinash Vasadi
 */
public class ElectronicsDriver {

    /**
     * A no argument constructor.
     */
    public ElectronicsDriver() {
    }

    /**
     * The ElectronicsDriverClass which contains the main method.
     *
     * @param args It takes arguments.
     * @throws FileNotFoundException It throws an exception when the file is not
     * found.
     * @throws ParseException It indicates that an error has been occurred
     * unexpectedly while parsing.
     */
    public static void main(String[] args) throws FileNotFoundException, ParseException {

        ArrayList<ElectronicDevices> devices = new ArrayList<>();
        Scanner data = new Scanner(new File("input.txt"));
        int deviceValue = 0;

        while (data.hasNext()) {
            deviceValue++;
            String device = "Device " + deviceValue + ": ";
            String inputtype = data.nextLine();
            if (inputtype.equals("electronic device")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                ElectronicDevices electronicdeviceobject = new ElectronicDevices(cost, year, make);
                System.out.println(device + electronicdeviceobject);
                devices.add(electronicdeviceobject);
            }
            if (inputtype.equals("gadget")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                double battery = Double.parseDouble(data.nextLine());
                double screenSize = Double.parseDouble(data.nextLine());
                ElectronicDevices gadget = new Gadgets(battery, screenSize, cost, year, make);
                System.out.println(device + gadget.expensiveOrNot());
                System.out.println("a. The method present in the Gadgets class is called, beacuse we are declaring an object of type ElctronicDevices but referencing with child class");
                Gadgets gadget1 = (Gadgets) gadget;
                System.out.println(device + gadget.expensiveOrNot());
                System.out.println("b. Here we are typecasting the ElectronicDevices object refference to the Gadget class beacuse it holds the childclass object.");
                System.out.println(device + gadget1.batteryLife());
                devices.add(gadget1);
                System.out.println(device + gadget);
            }
            if (inputtype.equals("android device")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                double battery = Double.parseDouble(data.nextLine());
                double screenSize = Double.parseDouble(data.nextLine());
                double version = Double.parseDouble(data.nextLine());
                ElectronicDevices android = new AndroidDevices(battery, screenSize, cost, year, make, version);
                AndroidDevices android1 = (AndroidDevices) android;
                System.out.println(device + android1.getVersionName() + "\n"
                        + device + android1.batteryLife() + "\n"
                        + device + android1.expensiveOrNot());
                System.out.println("c. JAVA doesn't support multiple inheritance with classes, it is possible in C++, python, etc..");
                System.out.println(device + android1);
                devices.add(android1);
            }
            if (inputtype.equals("IOS device")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                double battery = Double.parseDouble(data.nextLine());
                double screenSize = Double.parseDouble(data.nextLine());
                boolean version = Boolean.parseBoolean(data.nextLine());
                ElectronicDevices iosDevice = new IOSDevices(version, battery, screenSize, cost, year, make);
                IOSDevices iosDevice1 = (IOSDevices) iosDevice;
                System.out.println(device + iosDevice1.expensiveOrNot()
                        + "\n" + device + iosDevice1.getModelName());
                System.out.println(device + iosDevice1);
                devices.add(iosDevice1);
            }
            if (inputtype.equals("household device")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                double watts = Double.parseDouble(data.nextLine());
                double height = Double.parseDouble(data.nextLine());
                double width = Double.parseDouble(data.nextLine());
                double length = Double.parseDouble(data.nextLine());
                ElectronicDevices houseHoldDevice = new HouseholdDevices(watts, height, width, length, cost, year, make);
                System.out.println(device + houseHoldDevice);
                devices.add(houseHoldDevice);
            }
            if (inputtype.equals("oven")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                double watts = Double.parseDouble(data.nextLine());
                double height = Double.parseDouble(data.nextLine());
                double width = Double.parseDouble(data.nextLine());
                double length = Double.parseDouble(data.nextLine());
                String type = data.nextLine();
                ElectronicDevices oven = new Oven(watts, height, width, length, cost, year, make, type);
                Oven oven1 = (Oven) oven;
                System.out.println(device + oven1.getDeviceArea() + "\n"
                        + device + oven1.expensiveOrNot() + "\n"
                        + device + oven1.getWatts() + "\n"
                        + device + oven1.powerUsedInKWs(20));
                System.out.println(device + oven1);
                devices.add(oven1);
            }
            if (inputtype.equals("washing machine")) {
                double cost = Double.parseDouble(data.nextLine());
                String date = data.nextLine();
                SimpleDateFormat Date = new SimpleDateFormat("MM-dd-yyyy");
                Date year = Date.parse(date);
                String make = data.nextLine();
                double watts = Double.parseDouble(data.nextLine());
                double height = Double.parseDouble(data.nextLine());
                double width = Double.parseDouble(data.nextLine());
                double length = Double.parseDouble(data.nextLine());
                String type = data.nextLine();
                ElectronicDevices washingmachine = new WashingMachine(watts, height, width, length, cost, year, make, type);
                System.out.println(device + washingmachine);
                devices.add(washingmachine);
            }
        }
        for (ElectronicDevices allDevices : devices) {
            System.out.println(allDevices);
        }
    }

}

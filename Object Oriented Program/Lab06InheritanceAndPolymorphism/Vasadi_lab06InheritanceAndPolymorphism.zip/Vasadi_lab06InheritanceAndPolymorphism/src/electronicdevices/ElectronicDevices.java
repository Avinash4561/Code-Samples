/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.util.Date;

/**
 * This is the parent class.
 *
 * @author Avinash Vasadi
 */
public class ElectronicDevices {

    private double cost;
    private Date year;
    private String make;

    /**
     * A no argument constructor, sets the default values of cost and year.
     */
    public ElectronicDevices() {
        this.cost = 0.0;
        this.year = new Date(2004, 01, 01);
    }

    /**
     * A constructor with three arguments.
     *
     * @param cost It takes cost as an argument.
     * @param year It takes year as an argument.
     * @param make It takes make as an argument.
     */
    public ElectronicDevices(double cost, Date year, String make) {
        this.cost = cost;
        this.year = year;
        this.make = make;
    }

    /**
     * A method to device expensive based on cost.
     *
     * @return String
     */
    public String expensiveOrNot() {
        if (cost > 500) {
            return ("Device is Expensive");
        } else {
            System.out.println("main");
            return ("Device is Inexpensive");
        }
    }

    /**
     * A method to return cost
     *
     * @return double
     */
    public double getCost() {
        return cost;
    }

    /**
     * A method to set cost.
     *
     * @param cost It takes the cost as an argument.
     */
    public void setCost(double cost) {
        this.cost = cost;
    }

    /**
     * A method to get year.
     *
     * @return Date
     */
    public Date getYear() {
        return year;
    }

    /**
     * A method to set year.
     *
     * @param year It takes year as an argument.
     */
    public void setYear(Date year) {
        this.year = year;
    }

    /**
     * A method to get make
     *
     * @return String
     */
    public String getMake() {
        return make;
    }

    /**
     * A method to set make.
     *
     * @param make It takes make as an argument.
     */
    public void setMake(String make) {
        this.make = make;
    }

    /**
     * It overrides the toString method
     *
     * @return String
     */
    @Override
    public String toString() {
        return "ElectronicDevices{" + "cost= " + cost + ", year= " + year + ", make= " + make + '}';
    }

}

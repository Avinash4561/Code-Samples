/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.util.Date;

/**
 * It is a subclass of electronicDevices.
 *
 * @author Avinash Vasadi
 */
public class Gadgets extends ElectronicDevices {

    private double battery;
    private double screenSize;

    /**
     * A constructor with two arguments.
     *
     * @param battery It takes battery as an argument.
     * @param screenSize It takes screenSize as an argument.
     */
    public Gadgets(double battery, double screenSize) {
        this.battery = battery;
        this.screenSize = screenSize;

    }

    /**
     * A constructor with five arguments.
     *
     * @param battery It takes battery as an argument.
     * @param screenSize It takes screenSize as an argument.
     * @param cost It takes cost as an argument.
     * @param year It takes year as an argument.
     * @param make It takes make as an argument.
     */
    public Gadgets(double battery, double screenSize, double cost, Date year, String make) {
        super(cost, year, make);
        this.battery = battery;
        this.screenSize = screenSize;

    }

    /**
     * A method to calculate batteryLife based on battery.
     *
     * @return String
     */
    public String batteryLife() {
        if (battery > 5000) {
            return ("Has More Battery Life");
        } else {
            return ("Has less Battery Life");
        }
    }

    /**
     * A method to determine expensive based on cost.
     *
     * @return String
     */
    @Override
    public String expensiveOrNot() {
        if (this.getCost() > 1000) {
            return ("This Gadget is Expensive");
        } else {
            return ("This Gadget is Inexpensive");
        }
    }

    /**
     * A method to get battery.
     *
     * @return double
     */
    public double getBattery() {
        return battery;
    }

    /**
     * A method to set battery.
     *
     * @param battery It takes battery as an argument.
     */
    public void setBattery(double battery) {
        this.battery = battery;
    }

    /**
     * A method to get screen size.
     *
     * @return double
     */
    public double getScreenSize() {
        return screenSize;
    }

    /**
     * A method to set screen size.
     *
     * @param screenSize It takes screenSize as an argument.
     */
    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }

    /**
     * It overrides the toString method.
     *
     * @return String
     */
    @Override
    public String toString() {

        return super.toString() + " Gadgets{" + "battery= " + battery + ", screenSize= " + screenSize + '}';
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

/**
 * It is a subclass of HouseholdDevices
 *
 * @author Avinash Vasadi
 */
public class Oven extends HouseholdDevices {

    String type;

    /**
     * A constructor with eight arguments.
     *
     * @param watts It takes watts as an argument.
     * @param height It takes height as an argument.
     * @param width It takes width as an argument.
     * @param length It takes length as an argument.
     * @param cost It takes cost as an argument.
     * @param year It takes year as an argument.
     * @param make It takes make as an argument.
     * @param type It takes type as an argument.
     */
    public Oven(double watts, double height, double width, double length, double cost, java.util.Date year, java.lang.String make, java.lang.String type) {
        super(watts, height, width, length, cost, year, make);
        this.type = type;
    }

    /**
     * This method returns type.
     *
     * @return String
     */
    public String getType() {
        return type;
    }

    /**
     * This method sets type.
     *
     * @param type It takes type as an argument
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * It overrides toString method
     *
     * @return String
     */
    @Override
    public String toString() {
        return super.toString() + " Oven{" + "type =" + type + '}';
    }

}

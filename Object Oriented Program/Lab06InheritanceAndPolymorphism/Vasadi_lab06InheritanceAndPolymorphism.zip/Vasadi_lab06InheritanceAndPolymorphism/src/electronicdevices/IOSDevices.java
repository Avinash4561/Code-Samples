/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.util.Date;

/**
 * It is a subclass of Gadgets.
 *
 * @author Avinash Vasadi
 */
public class IOSDevices extends Gadgets {

    private boolean has3DTouch;

    /**
     * A constructor with six arguments.
     *
     * @param has3DTouch It takes has3DTouch as an argument.
     * @param battery It takes battery as an argument.
     * @param screenSize It takes screenSize as an argument.
     * @param cost It takes cost as an argument.
     * @param year It takes year as an argument.
     * @param make It takes make as an argument.
     */
    public IOSDevices(boolean has3DTouch, double battery, double screenSize, double cost, Date year, String make) {
        super(battery, screenSize, cost, year, make);
        this.has3DTouch = has3DTouch;
    }

    /**
     * This method returns model name based on screen size.
     *
     * @return String
     */
    public String getModelName() {
        if (this.getScreenSize() > 4.7) {
            return ("iPhone 7 Plus");
        } else {
            return ("iPhone 7");
        }
    }

    /**
     * It overrides toString method.
     *
     * @return String
     */
    @Override
    public String toString() {
        return super.toString() + " IOSDevices{" + "has3DTouch = " + has3DTouch + '}';
    }

}

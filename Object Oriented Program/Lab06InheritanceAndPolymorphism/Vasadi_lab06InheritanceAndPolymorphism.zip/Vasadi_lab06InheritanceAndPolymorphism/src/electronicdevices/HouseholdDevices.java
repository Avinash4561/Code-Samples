/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.util.Date;

/**
 * It is a subclass of ElectronicDevices.
 *
 * @author Avinash Vasadi
 */
public class HouseholdDevices extends ElectronicDevices {

    private double watts;
    private double height;
    private double width;
    private double length;

    /**
     * A constructor with seven arguments.
     *
     * @param watts It takes watts as an argument.
     * @param height It takes height as an argument.
     * @param width It takes width as an argument.
     * @param length It takes length as an argument.
     * @param cost It takes cost as an argument.
     * @param year It takes year as an argument.
     * @param make It takes make as an argument.
     */
    public HouseholdDevices(double watts, double height, double width, double length, double cost, Date year, String make) {
        super(cost, year, make);
        this.watts = watts;
        this.height = height;
        this.width = width;
        this.length = length;
    }

    /**
     * It overrides the super class method and returns the expense of the device
     * based on cost at this instant.
     *
     * @return String
     */
    @Override
    public String expensiveOrNot() {
        if (this.getCost() > 1500) {
            return ("This Household Device is Expensive");
        } else {
            return ("This Household Device is Inexpensive");
        }
    }

    /**
     * this method calculates the device area based on height, length and width.
     *
     * @return double
     */
    public double getDeviceArea() {
        return (this.height * this.length * this.width);
    }

    /**
     * This method returns the watts
     *
     * @return double
     */
    public double getWatts() {
        return watts;
    }

    /**
     * This method sets watts
     *
     * @param watts It takes the watts as an argument.
     */
    public void setWatts(double watts) {
        this.watts = watts;
    }

    /**
     * This method returns the height.
     *
     * @return double
     */
    public double getHeight() {
        return height;
    }

    /**
     * This method sets height
     *
     * @param height It takes height as an argument.
     */
    public void setHeight(double height) {
        this.height = height;
    }

    /**
     * This method returns width.
     *
     * @return double
     */
    public double getWidth() {
        return width;
    }

    /**
     * This method sets width.
     *
     * @param width It takes width as an argument
     */
    public void setWidth(double width) {
        this.width = width;
    }

    /**
     * This method returns length
     *
     * @return double
     */
    public double getLength() {
        return length;
    }

    /**
     * This method sets length
     *
     * @param length It takes length as an argument
     */
    public void setLength(double length) {
        this.length = length;
    }

    /**
     * This method calculates power used in kWs based on hours used and watts.
     *
     * @param hoursUsed It takes hoursUsed as an argument
     * @return double
     */
    public double powerUsedInKWs(double hoursUsed) {
        return ((hoursUsed * this.watts) / 1000);
    }

    /**
     * It overrides the toString method.
     *
     * @return String
     */
    @Override
    public String toString() {
        return super.toString() + " HouseholdDevices{" + "watts= " + watts + ", height= " + height + ", width= " + width + ", length= " + length + '}';
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

/**
 * It is a subclass of gadgets.
 *
 * @author Avinash Vasadi
 */
public class AndroidDevices extends Gadgets {

    private double version;

    /**
     *
     * @param battery It takes battery value as an argument.
     * @param screenSize It takes ScreenSize as an argument.
     * @param cost It takes battery cost as an argument.
     * @param year It takes battery year as an argument.
     * @param make It takes battery make as an argument.
     * @param version It takes battery version as an argument.
     */
    public AndroidDevices(double battery, double screenSize, double cost, java.util.Date year, java.lang.String make, double version) {
        super(battery, screenSize, cost, year, make);
        this.version = version;
    }

    /**
     * This method returns the version Name.
     *
     * @return String
     */
    public String getVersionName() {
        if (version < 5.0) {
            return ("Very old Android Device");
        } else {
            return ("Latest version");
        }
    }

    /**
     * It overrides toString method
     *
     * @return String
     */
    @Override
    public String toString() {
        return super.toString() + " AndroidDevices{version= " + version + '}';
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysonic;

/**
 *This class contains order details and calculations
 * @author Avinash Vasadi
 */
public class SonicOrder {

    private String milkshakeName;
    private String orderType;
    private String contactNumber;
    private String size;
    private static final double CLASSIC_SHAKE = 3.0;
    private static final double MASTER_SHAKE = 3.5;
    private static final double MASTER_BLAST = 3.75;
    private static final double WAFFLECONE_SUNDAE = 4.0;
    private String shakeToppings;
    private String extraIceCream;

    /**
     * A constructor with four arguments
     *
     * @param milkshakeName Name of milkshake ordered
     * @param orderType Order type of customer
     * @param contactNumber Contact number of the customer
     * @param size Size of the milkshake
     */
    public SonicOrder(String milkshakeName, String orderType, String contactNumber, String size) {
        this.milkshakeName = milkshakeName;
        this.orderType = orderType;
        this.contactNumber = contactNumber;
        this.size = size;
    }

    /**
     * A constructor with one argument
     *
     * @param contactNumber Contact number of the customer
     */
    public SonicOrder(String contactNumber) {
        this.contactNumber = "contactNumber";
        this.milkshakeName = "Chocolate MilkShake";
        this.orderType = "Dine In";
        this.size = "Regular";
    }

    /**
     * A Constructor without arguments
     */
    public SonicOrder() {

    }

    /**
     * It gets Name of milkshake ordered
     *
     * @return String
     */
    public String getmilkshakeName() {
        return this.milkshakeName;
    }

    /**
     * It gets Order type of customer
     *
     * @return String
     */
    public String getorderType() {
        return this.orderType;
    }

    /**
     * It gets Contact number of the customer
     *
     * @return String
     */
    public String getcontactNumber() {
        return this.contactNumber;
    }

    /**
     * It gets Size of the milkshake
     *
     * @return String
     */
    public String getsize() {
        return this.size;
    }

    /**
     * It gets Toppings on the milkshake separated by a comma.
     *
     * @return String
     */
    public String getshakeToppings() {
        return this.shakeToppings;
    }

    /**
     * It gets Flavor of ice cream scoops added to milk shake separated by
     * comma.
     *
     * @return String
     */
    public String getextraIceCream() {
        return this.extraIceCream;
    }

    /**
     * It sets milkshakeName
     *
     * @param milkshakeName Name of milkshake ordered
     */
    public void setmilkshakeName(String milkshakeName) {
        this.milkshakeName = milkshakeName;
    }

    /**
     * It sets orderType
     *
     * @param orderType Order type of customer
     */
    public void setorderType(String orderType) {
        this.orderType = orderType;
    }

    /**
     * It sets contactNumber
     *
     * @param contactNumber Contact number of the customer
     */
    public void setcontactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    /**
     * It sets size
     *
     * @param size Size of the milkshake
     */
    public void setsize(String size) {
        this.size = size;
    }

    /**
     * It sets shakeToppings
     *
     * @param shakeToppings Toppings on the milkshake separated by a comma
     */
    public void setshakeToppings(String shakeToppings) {
        this.shakeToppings = shakeToppings;
    }

    /**
     * It sets ice cream scoops
     *
     * @param extraIceCream Flavor of ice cream scoops added to milk shake
     * separated by comma
     */
    public void setextraIceCream(String extraIceCream) {
        this.extraIceCream = extraIceCream;
    }

    /**
     * It gets Total number of Toppings
     *
     * @return double
     */
    public double getTotalNumberToppings() {
        String[] count = shakeToppings.split(",");
        return (count.length);
    }

    /**
     * It gets Total number of Scoops
     *
     * @return double
     */
    public double getTotalNumberScoops() {
        String[] count = extraIceCream.split(",");
        return (count.length);
    }

    /**
     * It gets Total scoops cost
     *
     * @return double
     */
    public double getTotalScoopsCost() {
        String[] split = extraIceCream.split(",");
        int count = split.length;
        int i;
        double cost = 0, totalscoopscost = 0;
        for (i = 0; i < count; i++) {
            String type = split[i];
            switch (type) {
                case "Vanilla":
                    cost = 1.0;
                    break;
                case "Chocolate":
                    cost = 1.25;
                    break;
                case "Butterscotch":
                    cost = 2.5;
                    break;
                case "Strawberry":
                    cost = 2.75;
                    break;
                case "Blackberry":
                    cost = 2.25;
                    break;
                case "Caramel":
                    cost = 2.5;
                    break;
                case "Others":
                    cost = 3.0;
                    break;

            }
            totalscoopscost = totalscoopscost + cost;
        }
        return (totalscoopscost);
    }

    /**
     * It gets total Toppings cost
     *
     * @return double
     */
    @SuppressWarnings("ConvertToStringSwitch")
    public double getTotalToppingsCost() {
        String[] split = shakeToppings.split(",");
        int count = split.length;
        int i;
        @SuppressWarnings("UnusedAssignment")
                double cost = 0;
        double totaltoppingscost = 0;
        for (i = 0; i < count; i++) {
            if (split[i].equals("M&M")) {
                cost = 0.75;
            } else if (split[i].equals("Oreo")) {
                cost = 0.65;
            } else if (split[i].equals("ChocolateChips")) {
                cost = 0.99;
            } else {
                cost = 1.00;
            }
            totaltoppingscost = totaltoppingscost + cost;
        }

        return (totaltoppingscost);
    }

    /**
     * It gets Total cost
     *
     * @return double
     */
    public double getTotalCost() {
        double totalCost = 0, a, b = 0;
        if (milkshakeName.equals("MilkShake")) {
            totalCost = CLASSIC_SHAKE;
        }
        if (milkshakeName.equals("MasterShake")) {
            totalCost = MASTER_SHAKE;
        }
        if (milkshakeName.equals("MasterBlast")) {
            totalCost = MASTER_BLAST;
        }
        if (milkshakeName.equals("Wafflecone")) {
            totalCost = WAFFLECONE_SUNDAE;
        }
        if( !milkshakeName.equals("MasterBlast") && !milkshakeName.equals("MilkShake") && !milkshakeName.equals("MasterShake") && !milkshakeName.equals("Wafflecone"))
        {
            totalCost = CLASSIC_SHAKE;
        }
        if (getTotalNumberToppings() > 2) {
            totalCost = totalCost + 1;
        }
        if (getTotalNumberScoops() > 1) {
            totalCost = totalCost + totalCost * 0.1;
        }
        totalCost = totalCost + getTotalScoopsCost();
        totalCost = totalCost + getTotalToppingsCost();
        if (orderType.equals("Dine In")) {
            totalCost = totalCost - totalCost * 0.1;
        } else {
            totalCost = totalCost + totalCost * 0.1;
        }
        return (totalCost);
    }

    /**
     * It overrides inbuilt toString method
     * @return String
     */
    @Override
    public String toString() {
        return ("Number of Contact Customer: " + this.contactNumber
                + "\nOrdered Milkshake by Customer : " + this.getmilkshakeName()
                + "\nSize of Milkshake : " + this.getsize()
                + "\nToppings for milk shake : " + this.getshakeToppings()
                + "\nExtra Scoops of Ice-Cream : " + this.getextraIceCream()
                + "\n********************************************");
    }
}

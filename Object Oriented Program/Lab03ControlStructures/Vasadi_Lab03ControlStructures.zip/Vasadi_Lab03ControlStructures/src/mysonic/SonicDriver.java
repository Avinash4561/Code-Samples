/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysonic;
import java.util.Scanner;

/**
 * This class contains the main method
 * @author Avinash Vasadi
 */
public class SonicDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TO DO code application logic here
        String milkshakeName, contactNumber, size, shakeToppings, extraIceCream, orderType, order;
        Scanner sc = new Scanner(System.in);
        System.out.print("Welcome to Sonic!");
        do {
            System.out.print("Enter the Name of MilkShake: ");
            milkshakeName = sc.nextLine();
            System.out.print("Enter Contact Number :");
            contactNumber = sc.nextLine();
            System.out.print("Enter size of milkshake: ");
            size = sc.nextLine();
            System.out.print("Enter toppings you want to add: ");
            shakeToppings = sc.nextLine();
            System.out.print("Enter ice cream type you want to add: ");
            extraIceCream = sc.nextLine();
            System.out.print("Enter order type(Dine In/ Take Away): ");
            orderType = sc.nextLine();
            System.out.println("********************************************\n"
                    + "Your Order :");
            /**
             * Created SonicOrder object with four argument constructor
             */
            SonicOrder obj1 = new SonicOrder(milkshakeName, orderType, contactNumber, size);
            obj1.setshakeToppings(shakeToppings);
            obj1.setextraIceCream(extraIceCream);
            System.out.println(obj1.toString());
            System.out.println("Total Cost of Your Order : " + obj1.getTotalCost()
                    + "\n********************************************");
            System.out.println("Would you like order again? (Y/N): "
                    + "\n********************************************");
            order = sc.nextLine();
        } while (order.equals("Y"));
        System.out.println("Thank You and have a great day!");
    }

}

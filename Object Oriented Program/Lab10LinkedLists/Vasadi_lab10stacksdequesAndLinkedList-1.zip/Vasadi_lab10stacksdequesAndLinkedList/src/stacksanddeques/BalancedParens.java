/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stacksanddeques;

import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;

/**
 *
 * @author Avinash Vasadi
 */
public class BalancedParens {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        AStack<Character> parenStack = new AStack<>();
        Scanner sc = new Scanner(new File("expressions.txt"));
        while (sc.hasNext()) {
            String input = sc.nextLine();
            char[] input1 = input.toCharArray();
            for (int i = 0; i < input1.length; i++) {
                if (input1[i] == '(') {
                    parenStack.push(input1[i]);
                } else if (input1[i] == ')') {
                    if (parenStack.isEmpty()) {
                        System.out.println(input + ": INVALID:\nTrying to pop, but the stack is empty!");
                        parenStack.push(input1[i]);
                        i = input1.length;
                        System.out.println();
                    } else {
                        parenStack.pop();
                        if (i == input1.length - 1 && !parenStack.isEmpty()) {
                            System.out.println(input + ": INVALID:\nParsing complete, but the stack is not empty!\n");
                        } else if (i == input1.length - 1 && parenStack.isEmpty()) {
                            System.out.println(input + ": VALID");
                            System.out.println();
                        }
                    }
                } else if (i == input1.length - 1 && !parenStack.isEmpty()) {
                    System.out.println(input + ": INVALID:\nParsing complete, but the stack is not empty!");
                    System.out.println();
                } else if (i == input1.length - 1 && parenStack.isEmpty()) {
                    System.out.println(input + ": VALID");
                    System.out.println();
                }
            }
            while (!parenStack.isEmpty()) {
                parenStack.pop();
            }
        }

    }

}

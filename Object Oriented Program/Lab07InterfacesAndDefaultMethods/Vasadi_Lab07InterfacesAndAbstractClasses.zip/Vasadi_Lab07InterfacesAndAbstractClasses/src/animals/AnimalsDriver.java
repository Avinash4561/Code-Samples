/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Avinash Vasadi
 */
public class AnimalsDriver {
/**
 * 
 * @param args it takes arguments
 * @throws FileNotFoundException it throws exception when it occurs
 */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Scanner input = new Scanner(new File("input.txt"));
        while (input.hasNext()) {

            String animal = input.nextLine();

            if (animal.equals("DomesticAndWildAnimal")) {
                String animalName = input.nextLine();
                String skinType = input.nextLine();
                boolean mammal = Boolean.parseBoolean(input.nextLine());
                DomesticAndWildAnimals DW = new DomesticAndWildAnimals(skinType, mammal);
                System.out.println("This Animal is called as: " + animalName);
                System.out.println("Number of legs for this Animal: " + DW.getNumberOfLegs());
                System.out.println("This animal sounds: " + DW.getAnimalSound(animalName));
                System.out.println("This animal skin type is: " + DW.getGetBodyCovered());
                System.out.println("Explanation 1. It uses the overridden method present in DomesticAndWildAnimals which implements both WildAnimals and DomesticAnimals.");
                System.out.println("Explanation 2. The first way is to override the method in both the interfaces.Second way is to call the default method which is present in the interface. Here we have used the second way.");

            } else if (animal.equals("ExtinctAnimal")) {
                String animalName = input.nextLine();
                int yearOfExtinct = Integer.parseInt(input.nextLine());
                String animalType = input.nextLine();
                ExtinctAnimals EA = new GiganticExtinctAnimals(animalType, yearOfExtinct);
                System.out.println("Explanation 3. we cannot create an object for an abstract class, but to use those we can create an object of its subclass");
                System.out.println("Name of Extinct Animal: " + animalName);
                System.out.println("Food type of this Animal: " + EA.getFoodType());
                System.out.println("Year of Extinct: " + EA.getYearOfExtinct());

            } else {
                String animalName = input.nextLine();
                int yearOfExtinct = Integer.parseInt(input.nextLine());
                String animalType = input.nextLine();
                GiganticExtinctAnimals GA = new GiganticExtinctAnimals(animalType, yearOfExtinct);
                System.out.println("Explanation 4. No, it is not mandatory. An abstract can have zero abstract methods.");
                System.out.println("Type of Gigantic Extinct Animal: " + animalName);
                System.out.println("Name of Extinct Animal: " + GA.getAnimalType());
                System.out.println("Food type of this Animal: " + GA.getFoodType());
                System.out.println("Year of Extinct: " + GA.getYearOfExtinct());
                System.out.println("Explanation 5. yes, a class can implement more than one interface, but a class cannot extends more than one method.");

            }
        }

    }

}

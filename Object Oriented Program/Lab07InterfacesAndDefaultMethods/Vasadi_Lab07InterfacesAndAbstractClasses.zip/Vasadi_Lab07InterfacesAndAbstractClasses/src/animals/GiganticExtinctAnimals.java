/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Avinash Vasadi
 */
public class GiganticExtinctAnimals extends ExtinctAnimals {

    /**
     * A two argument constructor
     *
     * @param animalType It takes animal type as ana argument
     * @param yearOfExtinct It takes year of extinct as an argument
     */
    public GiganticExtinctAnimals(String animalType, int yearOfExtinct) {
        super(animalType, yearOfExtinct);
    }

    /**
     * It overrides Food type method in super class
     *
     * @return String
     */
    @Override
    public String getFoodType() {
        if (this.getAnimalType().equals("Brachiosaurus")) {
            return ("Plant Eater(Herbivores)");
        } else if (this.getAnimalType().equals("Baryonyx")) {
            return ("Meat-eaters (carnivores or theropods)");
        } else {
            return ("omnivores (eating both plants and animals)");
        }
    }

    /**
     * It overrides and returns the number of legs
     *
     * @return Integer
     */
    @Override
    public int getNumberOfLegs() {
        return (Animals.NUMBER_OF_LEGS);
    }

}

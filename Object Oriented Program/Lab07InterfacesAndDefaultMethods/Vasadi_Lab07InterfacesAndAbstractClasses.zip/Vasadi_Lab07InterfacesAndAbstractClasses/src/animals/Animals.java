/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Avinash Vasadi
 */
public interface Animals {
    
    public static final int NUMBER_OF_LEGS = 4;
    /**
     * This is an abstract method
     * @return Integer 
     */
    public int getNumberOfLegs();
}

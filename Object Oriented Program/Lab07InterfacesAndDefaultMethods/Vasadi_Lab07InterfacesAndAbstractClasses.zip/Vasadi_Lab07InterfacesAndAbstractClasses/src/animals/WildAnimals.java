/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Avinash Vasadi
 */
public interface WildAnimals extends Animals {

    /**
     * It is a default method
     *
     * @param animal It takes animal name as an argument
     * @return String
     */
    default String getAnimalSound(String animal) {

        if (animal.equals("Lion")) {
            return ("Roar");
        } else if (animal.equals("Tiger")) {
            return ("Grrr");
        } else {
            return ("Wild Animal Not Found");
        }
    }

}

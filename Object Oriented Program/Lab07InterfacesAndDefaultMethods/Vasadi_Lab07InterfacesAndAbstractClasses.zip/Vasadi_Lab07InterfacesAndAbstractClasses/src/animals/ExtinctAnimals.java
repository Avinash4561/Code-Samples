/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Avinash Vasadi
 */
public abstract class ExtinctAnimals implements Animals {

    private String animalType;
    private int yearOfExtinct;

    /**
     * A two argument constructor
     *
     * @param animalType It takes type of the animal as an argument
     * @param yearOfExtinct It takes the year of extinct as an argument
     */
    public ExtinctAnimals(String animalType, int yearOfExtinct) {
        this.animalType = animalType;
        this.yearOfExtinct = yearOfExtinct;
    }

    /**
     * It returns the type of animal
     *
     * @return String
     */
    public String getAnimalType() {
        return animalType;
    }

    /**
     * It sets the type of animal
     *
     * @param animalType It takes animal type as an argument
     */
    public void setAnimalType(String animalType) {
        this.animalType = animalType;
    }

    /**
     * It returns the year of extinct of the animal
     *
     * @return Integer
     */
    public int getYearOfExtinct() {
        return yearOfExtinct;
    }

    /**
     * It sets the year of extinct of the animal
     *
     * @param yearOfExtinct It takes the year of extinct as ana argument
     */
    public void setYearOfExtinct(int yearOfExtinct) {
        this.yearOfExtinct = yearOfExtinct;
    }

    /**
     * It is an abstract method
     *
     * @return String
     */
    public abstract String getFoodType();

    /**
     * It overrides the to string method
     *
     * @return String
     */
    @Override
    public String toString() {
        return "ExtinctAnimals{" + "animalType=" + animalType + ", yearOfExtinct=" + yearOfExtinct + '}';
    }

}

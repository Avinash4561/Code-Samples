/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Avinash Vasadi
 */
public interface DomesticatedAnimals extends Animals {

    /**
     * A default method
     *
     * @param animal It takes animal as an argument
     * @return String
     */
    default String getAnimalSound(String animal) {
        if (animal.equals("Dog")) {
            return ("bow-wow");
        } else if (animal.equals("Cat")) {
            return ("Meow");
        } else {
            return ("Domestic Animal Not Found");
        }
    }

}

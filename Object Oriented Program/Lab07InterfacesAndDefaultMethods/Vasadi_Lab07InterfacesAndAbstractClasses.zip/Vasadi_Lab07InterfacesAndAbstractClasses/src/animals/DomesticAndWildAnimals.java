/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Avinash Vasadi
 */
public class DomesticAndWildAnimals implements DomesticatedAnimals, WildAnimals {

    public String getBodyCovered;
    private boolean mammal;

    /**
     * This is a two argument constructor.
     *
     * @param getBodyCovered It takes BodyCovered.
     * @param mammal It takes mammal.
     */
    public DomesticAndWildAnimals(String getBodyCovered, boolean mammal) {
        this.getBodyCovered = getBodyCovered;
        this.mammal = mammal;
    }

    /**
     * This method returns body covered
     *
     * @return String
     */
    public String getGetBodyCovered() {
        return getBodyCovered;
    }

    /**
     * This method sets body covered
     *
     * @param getBodyCovered It takes body covered as an argument
     */
    public void setGetBodyCovered(String getBodyCovered) {
        this.getBodyCovered = getBodyCovered;
    }

    /**
     * This method returns whether the animal is a mammal or not.
     *
     * @return boolean
     */
    public boolean isMammal() {
        return mammal;
    }

    /**
     * This method sets mammal type
     *
     * @param mammal It takes mammal type as an argument
     */
    public void setMammal(boolean mammal) {
        this.mammal = mammal;
    }

    /**
     * It returns the number of legs
     *
     * @return Integer
     */
    @Override
    public int getNumberOfLegs() {
        return (Animals.NUMBER_OF_LEGS);
    }

    /**
     * It takes animal as an argument and returns animal sound
     *
     * @param animal It takes animal as ana argument
     * @return String
     */
    @Override
    public String getAnimalSound(String animal) {

        return (DomesticatedAnimals.super.getAnimalSound(animal));
    }

    /**
     * It overrides the to string method
     *
     * @return String
     */
    @Override
    public String toString() {
        return "DomesticAndWildAnimals{" + "getBodyCovered=" + getBodyCovered + ", mammal=" + mammal + '}';
    }

}

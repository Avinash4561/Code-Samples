/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 * It is a subclass of four wheeler.
 *
 * @author Avinash Vasadi
 */
public class Car extends FourWheeler {

    private String name;
    private long initialDistance;
    private long finalDistance;
    private double initialGasQuantity;
    private double finalGasQuantity;

    /**
     * This is a No-argument Constructor.
     */
    public Car() {
        super();
    }

    /**
     * This Constructor takes six input arguments.
     *
     * @param initialDistance It takes initial distance as argument.
     * @param finalDistance It takes final distance as argument.
     * @param initialGasQuantity It takes initialGasQuantity as argument.
     * @param finalGasQuantity It takes finalGasQuantity as argument.
     * @param manufacturerName It takes manufacturerName as argument.
     * @param v_Id It takes Vehicle Id as argument.
     */
    public Car(long initialDistance, long finalDistance, double initialGasQuantity, double finalGasQuantity, String manufacturerName, int v_Id) {
        super(manufacturerName, v_Id);
        this.initialDistance = initialDistance;
        this.finalDistance = finalDistance;
        this.initialGasQuantity = initialGasQuantity;
        this.finalGasQuantity = finalGasQuantity;
        this.name = "Car";
    }

    /**
     * A method to calculate Gas based on initial and final gas quantity.
     *
     * @return double
     */
    public double calculateGas() {
        return (0.264172 * (initialGasQuantity - finalGasQuantity));
    }

    /**
     * A method to calculate Distance based on initial and final distance.
     *
     * @return double
     */
    public double calculateDistance() {
        return (0.621371 * (finalDistance - initialDistance));
    }

    /**
     * A method to calculate mileage based on the distance and gas consumed.
     *
     * @return double
     */
    public double calculateMileage() {

        return (this.calculateDistance() / this.calculateGas());
    }

    /**
     * It overrides toString method and returns the desired output format.
     *
     * @return String
     */
    @Override
    public String toString() {
        super.toString();
        return ("Manufacturer Name:" + this.getManufacturerName() + "\nVehicle Id:" + this.getV_Id()
                + "\nType of Vehicle:" + this.name + "\nThe distance travelled is:" + calculateDistance()
                + "\nThe gas consumed to cover the distance:" + calculateGas()
                + "\nThe Mileage of the vehicle is:" + calculateMileage());
    }

}

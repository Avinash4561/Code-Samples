/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 * It is a sub class of vehicle.
 *
 * @author Avinash Vasadi
 */
public class TwoWheeler extends Vehicle {

    private String message;

    /**
     * A no-argument constructor.
     */
    public TwoWheeler() {
    }

    /**
     * A constructor with two arguments.
     *
     * @param manufacturerName It takes manufacturer name as argument.
     * @param v_Id It takes Vehicle Id as argument.
     */
    public TwoWheeler(String manufacturerName, int v_Id) {
        super(manufacturerName, v_Id);
        this.message = "";
    }

    /**
     * A method to identify the vehicle category.
     *
     * @param category It takes category as argument.
     * @return String
     */
    public String identifier(String category) {
        if (category.equals("Petrol")) {
            message = "is a super bike";
        } else if (category.equals("Pedalpowered")) {

            message = "is a cycle ";
        }
        return (message);
    }

    /**
     * It overrides toString method and returns the desired output format.
     *
     * @return String
     */
    @Override
    public String toString() {
        return ("\nThe TwoWheeler " + message);
    }

}

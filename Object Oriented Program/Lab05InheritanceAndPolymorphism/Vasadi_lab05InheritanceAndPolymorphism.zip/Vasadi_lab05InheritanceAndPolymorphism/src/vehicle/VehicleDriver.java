/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * This is the Driver class.
 *
 * @author Avinash Vasadi
 */
public class VehicleDriver {

    /**
     * It contains main method.
     *
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException it throws an exception when ever
     * the file not found.
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here

        Scanner sc = new Scanner(new File("vehicle.txt"));
        Vehicle details = new Vehicle(sc.nextLine(), Integer.parseInt(sc.nextLine()));
        System.out.println("Vehicle Details:");
        System.out.println(details);
        System.out.println("*********************************************************");
        while (sc.hasNext()) {
            switch (sc.nextLine()) {
                case "Four Wheeler":
                    switch (sc.nextLine()) {
                        case "Car":
                            Car Details = new Car(Long.parseLong(sc.nextLine()), Long.parseLong(sc.nextLine()), Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine()), details.getManufacturerName(), details.getV_Id());
                            System.out.println("Four Wheeler Details:");
                            System.out.println(Details);
                            System.out.println("*********************************************************");
                            break;
                        case "Truck":
                            Truck parts = new Truck("Maserati", 12345);
                            parts.addAccessories(sc.nextLine());
                            System.out.println("Four Wheeler Details:");
                            System.out.println(parts);
                            System.out.println("*********************************************************");
                            break;
                    }
                    break;
                case "TwoWheeler":
// Here the Bike class object is created instead of Two Wheeler cladss object, where the Bike class is the subclass of Two Wheeler class it inherits all the meethods of parent class.
                    Bike bikeObject = new Bike(sc.nextLine(), Integer.parseInt(sc.nextLine()));
                    System.out.println("Two Wheeler Details:");
                    bikeObject.identifier(sc.nextLine());
                    System.out.println(bikeObject);
                    System.out.println("*********************************************************");
                    break;

            }
        }
        System.out.println("Congratulations,End of the program!");
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 * It is a super class.
 *
 * @author Avinash Vasadi
 */
public class Vehicle {

    private String manufacturerName;
    private int v_Id;

    /**
     * A No-argument constructor.
     */
    public Vehicle() {

    }

    /**
     * A constructor with two arguments.
     *
     * @param manufacturerName It takes Manufacturer name as argument.
     * @param v_Id It takes Vehicle Id as argument.
     */
    public Vehicle(String manufacturerName, int v_Id) {
        this.manufacturerName = manufacturerName;
        this.v_Id = v_Id;
    }

    /**
     * A method to get manufacturer name.
     *
     * @return String
     */
    public String getManufacturerName() {
        return manufacturerName;
    }

    /**
     * A method to set manufacturer name.
     *
     * @param manufacturerName It takes manufacturer name as argument.
     */
    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    /**
     * A method to get Vehicle ID.
     *
     * @return integer
     */
    public int getV_Id() {
        return v_Id;
    }

    /**
     * A method to set Vehicle ID.
     *
     * @param v_Id It takes Vehicle Id as argument.
     */
    public void setV_Id(int v_Id) {
        this.v_Id = v_Id;
    }

    /**
     * It overrides toString method and returns the desired output format.
     *
     * @return String
     */
    @Override
    public String toString() {
        return ("ManufacturerName:" + manufacturerName + " Vehicle Id:" + v_Id);
    }

}

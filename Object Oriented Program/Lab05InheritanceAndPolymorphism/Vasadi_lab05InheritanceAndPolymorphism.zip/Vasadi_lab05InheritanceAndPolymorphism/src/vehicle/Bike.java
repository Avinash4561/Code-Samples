/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 * It is a subclass of Two wheeler class.
 *
 * @author Avinash Vasadi
 */
public class Bike extends TwoWheeler {

    private String name;

    /**
     * This is a No-argument constructor.
     */
    public Bike() {
    }

    /**
     * A Constructor with two arguments.
     *
     * @param manufacturerName It takes manufacturer name as argument
     * @param v_Id It takes vehicle Id as argument.
     */
    public Bike(String manufacturerName, int v_Id) {
        super(manufacturerName, v_Id);
        this.name = "Bike";
    }

    /**
     * It overrides the toString method and returns output in desired format.
     *
     * @return String
     */
    @Override
    public String toString() {
        super.toString();
        return ("Manufacturer Name:" + this.getManufacturerName() + "\nVehicle Id:" + this.getV_Id()
                + super.toString());
    }

}

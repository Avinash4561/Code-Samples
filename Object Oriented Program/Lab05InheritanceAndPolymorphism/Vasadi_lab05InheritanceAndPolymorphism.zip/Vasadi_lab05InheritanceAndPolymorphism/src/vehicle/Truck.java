/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 * It is a subclass of four wheeler.
 *
 * @author Aviansh Vasadi
 */
public class Truck extends FourWheeler {

    private String name;
    private final double BASE_PRICE = 30.0;

    /**
     * A No-argument constructor which calls the super class No-argument
     * constructor.
     */
    public Truck() {
        super();
    }

    /**
     * A constructor with two arguments.
     *
     * @param manufacturerName It takes manufacturer name as argument.
     * @param v_Id It takes Vehicle Id as argument.
     */
    public Truck(String manufacturerName, int v_Id) {
        super(manufacturerName, v_Id);
        this.name = "Truck";
    }

    /**
     * A method to calculate extra fittings cost.
     *
     * @return double
     */
    public double calculateExtraFittingCost() {
        double cost = 0;
        for (String split : getAccessories()) {
            switch (split) {
                case "Floor Mats":
                    cost += 39;
                    break;
                case "Side Covers":
                    cost += 50;
                    break;
                case "Headlights":
                    cost += 90;
                    break;
                case "Custom Grilles":
                    cost += 101;
                    break;
                case "Audio System":
                    cost += 70;
                    break;
                default:
                    break;
            }

        }
        return (cost + BASE_PRICE);
    }

    /**
     * It overrides toString method and returns the desired output format.
     *
     * @return String
     */
    @Override
    public String toString() {
        return ("Manufacturer Name:" + this.getManufacturerName() + "\nVehicle Id:" + this.getV_Id() + "\nType of Vehicle:" + this.name + "\nThe total cost of Extra Interiors is:" + calculateExtraFittingCost());
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.util.ArrayList;

/**
 * It is a subclass of vehicle.
 *
 * @author Avinash Vasadi
 */
public class FourWheeler extends Vehicle {

    private ArrayList<String> accessories;

    /**
     * A No-argument constructor which calls the super class No-argument
     * constructor.
     */
    public FourWheeler() {
        super();
    }

    /**
     * A constructor with two arguments.
     *
     * @param manufacturerName It takes manufacturer name as argument.
     * @param v_Id It takes vehicle Id as argument.
     */
    public FourWheeler(String manufacturerName, int v_Id) {
        super(manufacturerName, v_Id);
        accessories = new ArrayList<>();
    }

    /**
     * A method to get accessories.
     *
     * @return ArrayList
     */
    public ArrayList<String> getAccessories() {
        return accessories;
    }

    /**
     * A method to set accessories in an ArrayList.
     *
     * @param accessories It takes accessories as argument.
     */
    public void setAccessories(ArrayList<String> accessories) {
        this.accessories = accessories;
    }

    /**
     * A method to add accessories and return accessories.
     *
     * @param items It takes items as argument.
     * @return ArrayList
     */
    public ArrayList<String> addAccessories(String items) {
        int c = 0, i;
        for (i = 0; i < items.split(",").length - 1; i++) {
            this.accessories.add(items.substring(c, items.indexOf(",", c)));
            c = items.indexOf(",", c) + 1;
        }
        if (i == items.split(",").length - 1) {
            accessories.add(items.substring(c, items.length()));
        }
        return (accessories);
    }

}

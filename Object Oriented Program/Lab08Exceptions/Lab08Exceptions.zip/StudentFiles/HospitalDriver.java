/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 * Application launches from this class
 *
 * @author Instructor
 */
public class HospitalDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException Throws if file is not found
     * @throws java.text.ParseException Parse the exception if there parsing has
     * problems
     */
    public static void main(String[] args) throws FileNotFoundException, ParseException {
        // TODO code application logic here
	
	//1. Declare and initialize a scanner object "sc" to read from the file "input.txt"

        //2. Create an object for List of doctors with variable name as doctors list and initialize it with arraylist.
        // Declare variable count of type int and declare it to a value of 0. Also declare variables docname, SpecialityType, officeHours of type String.
        // Create an object for AbstarctHospitalInfo with variable name as hospitalInfo and initialize it with ChildWard class.

	//3. while input.txt has more data(While loop starts here) {
        //  If the Passed type is "Doctor" then, Read in the data, and store them to the respective variables such as,
        //  docname, specialityType, officeHours. Initlaize the multiple argument contructor of Doctor class with the mentioned variables.
        //  Using a try , catch block add the the doctor to the hospitalInfo. 
        //  3a. Else scan the next line and store the data into genderstring variable. Now declare a variable gender of type char and store the character at
        //      0th position in the genderstring to the ageString variable. Store this age into a variable age of type int. Now among this stored age, if the age is less than 16
        //      scan the details of hospital and store them accordingly into  hospitalName, hospitalAddress, childFName, childLName of type String, 
        //      insuranceID of type int, lastdateString of type String.
        //      Now declare DateFormat class and initialize it to simpleDateFormat class of format "MM/dd/yyy" . Declare a varialbe of type Date and variable name as 
        //      lastCheckUpDate and parse the lastDateString. Declare a variable lastCheckUpStatusString of type String and scan the data.
        //      Declare a variable lastCheckUpStatus of type boolean. If the status is "true" is equal to status of lastCheckUpStatusString(HINT: Use .equals),
        //      then declare a variable lastDoctorVisited of type String and scan the data.

	//  3a(i) Create an object for ChildWard class with variable name as childWard and initialize the multiple argument contructor of ChildWard Class.
                    //        Test the toString method of child ward class. Using try catch block assign the doctor to the patient from the available doctors list in the hospital info to the patient in child ward.
	//    Create a variable billingDetails of type String and scan the data, also create a variable childBillGenerated of type double and invoke the calculate bill method
                    //    of childward using the scanned billing details. Print the last check updetails of the patient in child ward.             
	//    Create a variable InsuranceCompany of type String and scan the data, also create a variable  InsuranceCoverage of type double and parse the data
	// 3a(ii)  Now create an object for ChildInsurance of variable name childInsurance and invoke multiple argument contructor of childInsurance class.
                    //         Test the toString method of child insurance class. Using try catch block invoke the chekcHealthInsurancePlan in childinsurance class and store the returned value in
                    //         inusrancePlanName variable of type String,create a variable premiumPaid of type double and scan the data. Now using one more try catch block
                    //         invoke the calcAmountPayableToHospital method of child insurance class and store the returned value in amountPayable variable of type double.

	// 3(b) Else if age is greater than 16 and gender is female then scan the data like hospitalname, hospitalAddress, adultFName, adultLname of type String.
                //      also scan insuranceID of type int. lastdateString of type String.
                //      Now declare DateFormat class and initialize it to simpleDateFormat class of format "MM/dd/yyy" . Declare a varialbe of type Date and variable name as 
                //      lastCheckUpDate and parse the lastDateString. Declare a variable lastCheckUpStatusString of type String and scan the data.
                //      Declare a variable lastCheckUpStatus of type boolean. If the status is "true" is equal to status of lastCheckUpStatusString(HINT: Use .equals),
                //      then declare a variable lastDoctorVisited of type String and scan the data.

	//  3b(i) Create an object for MaternityWard class with variable name as maternityWard and initialize the multiple argument contructor of MaternityWard Class.
                    //        Test the toString method of maternity ward class. Using try catch block assign the doctor to the patient from the available doctors list in the hospital info to the patient in maternity ward.

		//    Create a variable billingDetails of type String and scan the data, also create a variable adultBillGenerated of type double and invoke the calculate bill method
                    //    of maternityWard using the scanned billing details. Print the last check updetails of the patient in maternity ward. 

	//  Create a variable InsuranceCompany of type String and scan the data, also create a variable  InsuranceCoverage of type double and parse the data
	// 3b(ii)  Now create an object for AdultInsurance of variable name adultInsurance and invoke multiple argument contructor of AdultInsurance class.
                    //         Test the toString method of adult insurance class. Using try catch block invoke the chekcHealthInsurancePlan in adultinsurance class and store the returned value in
                    //         inusrancePlanName variable of type String,create a variable premiumPaid of type double and scan the data. Now using one more try catch block
                    //         invoke the calcAmountPayableToHospital method of Adult insurance class and store the returned value in amountPayable variable of type double.
	}// Else if of age comparsion ends here
            } // Else part ends here
        } // While loop Ends here
	//4. Iterate through the list of available doctors of type Doctor using the object of Abstarct hospital using an enhance for loop and test the toString method
} // For Loop ends
    } // Main method Ends
} // Class Ends
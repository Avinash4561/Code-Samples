/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;

/**
 * Class contains patient details
 *
 * @author Avinash Vasadi
 */
public class Patient {

    /**
     * First name of the Patient
     */
    private String fName;
    /**
     * Last name of the Patient
     */
    private String lName;
    /**
     * Insurance id of the patient
     */
    private int insuranceID;
    /**
     * Age of the Patient in years
     */
    private int age;
    /**
     * Gender of the patient
     */
    private char gender;
    /**
     * Last check up date of the patient
     */
    private Date lastCheckUpDate;
    /**
     * Last check up status
     */
    private boolean lastCheckUpStatus;
    /**
     * Last doctor patient has visited
     */
    private String lastDoctorVisited;

    /**
     * No argument constructor. Does nothing
     */
    public Patient() {
    }

    /**
     * Initializes the variables of patient
     *
     * @param fName First name
     * @param lName Last Name
     * @param insuranceID Insurance id of patient
     * @param age Age of the patient
     * @param gender Gender of the patient
     * @param lastCheckUpDate Last check up date of the patient
     * @param lastCheckUpStatus Last check up status
     * @param lastDoctorVisited last doctor visited
     */
    public Patient(String fName, String lName, int insuranceID, int age, char gender, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited) {
        this.fName = fName;
        this.lName = lName;
        this.insuranceID = insuranceID;
        this.age = age;
        this.gender = gender;
        this.lastCheckUpDate = lastCheckUpDate;
        this.lastCheckUpStatus = lastCheckUpStatus;
        this.lastDoctorVisited = lastDoctorVisited;
    }

    /**
     * Returns the insurance id of the Patient
     *
     * @return Insurance id
     */
    public int getInsuranceID() {
        return insuranceID;
    }

    /**
     * Sets the insurance id of he patient
     *
     * @param insuranceID Insurance id value
     */
    public void setInsuranceID(int insuranceID) {
        this.insuranceID = insuranceID;
    }

    /**
     * Returns the age of the patient
     *
     * @return Age
     */
    public int getAge() {
        return age;
    }

    /**
     * Sets the Age of the Patient
     *
     * @param age Age of patient
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Returns the gender of the patient
     *
     * @return Gender
     */
    public char getGender() {
        return gender;
    }

    /**
     * Sets the gender of the patient
     *
     * @param gender Gender
     */
    public void setGender(char gender) {
        this.gender = gender;
    }

    /**
     * Returns the first name of the patient
     *
     * @return First Name
     */
    public String getfName() {
        return fName;
    }

    /**
     * Sets the first name of the patient
     *
     * @param fName First name
     */
    public void setfName(String fName) {
        this.fName = fName;
    }

    /**
     * Returns the Last name of the Patient
     *
     * @return Last name
     */
    public String getlName() {
        return lName;
    }

    /**
     * Sets the Last name of the patient
     *
     * @param lName Last Name
     */
    public void setlName(String lName) {
        this.lName = lName;
    }

    /**
     * Returns the check up status. If last check up status is true return last
     * check up date, last doctor visited, last check up status(Return this as
     * success or failure for true or false respectively). See Sample Output for
     * formatting
     *
     * @return Check up details
     */
    public String getLastCheckUpDetails() {
        if (lastCheckUpStatus) {
            return "Last Check Up Date: " + lastCheckUpDate + "Last Doctor Visited: " + lastDoctorVisited + "Last Check Up Status: " + "Success";
        } else {
            return "Last Check Up Date: " + lastCheckUpDate + "Last Doctor Visited: " + lastDoctorVisited + "Last Check Up Status: " + "Failure";
        }
    }

    /**
     * String representation of Patient details. Look at Sample output for
     * formatting
     *
     * @return String format representation of patient details
     */
    @Override
    public String toString() {
        return "First Name: " + fName + "\nLast Name: " + lName + "\nInsurance ID: " + insuranceID + "\nAge: " + age + "\nGender: " + gender;
    }

}

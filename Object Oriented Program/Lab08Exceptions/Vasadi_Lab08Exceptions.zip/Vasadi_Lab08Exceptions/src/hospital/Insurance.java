/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 * Contains insurance details
 *
 * @author Avinash Vasadi
 */
public interface Insurance {

    /**
     * Represents Base premium amount in dollars, a patient paid for his policy and assign
     * 600.00 as its value
     */
    double BASE_PREMIUM_AMOUNT = 600.00;

    /**
     * Checks the insurance plan of the patient
     *
     * @return Insurance Plan
     * @throws InvalidInsuranceIDException if an invalid ID for insurance
     * is passed
     */
    String checkHealthInsurancePlan() throws InvalidInsuranceIDException;

    /**
     * Calculates the amount a patient needs to pay to the hospital in dollars
     *
     * @param PremiumPaid Premium paid by the patient
     * @param billGenerated Bill generated at hospital
     * @return Payable amount to hospital
     * @throws NegativeAmountException Throws if the payable amount goes to
     * negative values
     */
    double calcAmountPayableToHospital(double PremiumPaid, double billGenerated) throws NegativeAmountException;
}

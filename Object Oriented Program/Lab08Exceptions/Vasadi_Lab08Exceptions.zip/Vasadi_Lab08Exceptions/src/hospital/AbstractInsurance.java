/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;

/**
 * Contains insurance details and checks the health insurance plans.
 *
 * @author Avinash Vasadi
 */
public abstract class AbstractInsurance extends Patient implements Insurance {

    /**
     * Name of the Insurance company of type String
     */
    private String InsuranceCompanyName;

    /**
     * Insurance coverage for the patients of type double
     */
    private double InsuranceCoverage;

    /**
     * Initializes all the variables in Patient and AbstractInsurance.
     * @param InsuranceCompanyName Name of the Insurance Company
     * @param InsuranceCoverage Insurance coverage
     * @param fName First Name
     * @param lName Last Name
     * @param insuranceID Insurance id of the patient
     * @param age Age of the Patient
     * @param gender Gender of the Patient
     * @param lastCheckUpDate Last check up date of the patient
     * @param lastCheckUpStatus last check up status of the patient
     * @param lastDoctorVisited Last time doctor whom patient has visited
     */
    public AbstractInsurance(String InsuranceCompanyName, double InsuranceCoverage, String fName, String lName, int insuranceID, int age, char gender, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited) {
        super(fName, lName, insuranceID, age, gender, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited);
        this.InsuranceCompanyName = InsuranceCompanyName;
        this.InsuranceCoverage = InsuranceCoverage;
    }

    /**
     * Returns the name of the insurance company
     *
     * @return Insurance company name
     */
    public String getInsuranceCompanyName() {
        return InsuranceCompanyName;
    }

    /**
     * Return the insurance coverage value
     *
     * @return Insurance Coverage
     */
    public double getInsuranceCoverage() {
        return InsuranceCoverage;
    }

    /**
     * Checks the insurance plan based on the range of the insurance ID. If
     * the insurance id is greater than 0 and and less than 10000 then insurance
     * plan is "Health maintenance organizations (HMOs) plan". Else if the
     * insurance id is greater than or equal to 10000 and less than 20000 then
     * the insurance plan is "Preferred provider organizations (PPOs) plan".Else
     * if the insurance id is greater than or equal to 20000 and less than 30000
     * then the insurance plan is "Point-of-service (POS) plan". Else if the
     * insurance id is greater than or equal to 30000 and less than 40000 then
     * the insurance plan is "High-deductible health plans (HDHPs)"
     *
     * @return Insurance Plan
     * @throws InvalidInsuranceIDException Throws if the invalid insurance id is
     * passed
     */
    @Override
    public String checkHealthInsurancePlan() throws InvalidInsuranceIDException {
        if (super.getInsuranceID() > 0 && super.getInsuranceID() < 10000) {
            return "Health maintenance organizations (HMOs) plan";
        } else if (super.getInsuranceID() >= 10000 && super.getInsuranceID() < 20000) {
            return "Preferred provider organizations (PPOs) plan";
        } else if (super.getInsuranceID() >= 20000 && super.getInsuranceID() < 30000) {
            return "Point-of-service (POS) plan";
        } else if (super.getInsuranceID() >= 30000 && super.getInsuranceID() < 40000) {
            return "High-deductible health plans (HDHPs)";
        } else {
            throw new InvalidInsuranceIDException("InvalidInsuranceIDException: InsuranceID is out of bounds.");
        }
    }

    /**
     * Abstract method to calculate the amount payable to hospital
     *
     * @param PremiumPaid Premium paid to the Hospital
     * @param billGenerated Bill that has generated
     * @return Amount payable to hospital
     * @throws NegativeAmountException Throws if the amount is is negative
     * values
     */
    @Override
    public abstract double calcAmountPayableToHospital(double PremiumPaid, double billGenerated) throws NegativeAmountException;

    /**
     * Returns private variables separated by one space. Check the sample
     * output for details.
     *
     * @return A String representation of Insurance company
     */
    @Override
    public String toString() {
        return "AbstractInsurance{" + "InsuranceCompanyName=" + InsuranceCompanyName + ", InsuranceCoverage=" + InsuranceCoverage + '}';
    }
}

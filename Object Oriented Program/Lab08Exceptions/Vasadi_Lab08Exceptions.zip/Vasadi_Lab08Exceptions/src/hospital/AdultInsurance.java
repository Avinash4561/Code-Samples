/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;

/**
 * Class contains details of adult insurance
 * @author Avinash Vasadi
 */
public class AdultInsurance extends AbstractInsurance{

    /**
     * Initializes the variables by calling the super class constructor
     * @param InsuranceCompanyName Name of the insurance company
     * @param InsuranceCoverage Insurance coverage for an adult
     * @param fName First Name of the Adult
     * @param lName Last Name of the Adult
     * @param insuranceID Insurance ID of the Adult
     * @param age Age of the adult
     * @param gender Gender of the adult
     * @param lastCheckUpDate Last check up date of the adult
     * @param lastCheckUpStatus Last check up status of the patient
     * @param lastDoctorVisited  Last doctor visited by the adult
     */
    public AdultInsurance(String InsuranceCompanyName, double InsuranceCoverage, String fName, String lName, int insuranceID, int age, char gender, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited) {
        super(InsuranceCompanyName, InsuranceCoverage, fName, lName, insuranceID, age, gender, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited);
    }
    
    /**
     * Calculates the amount payable to hospital by the adult customer. If the 
     * premium paid by the customer is less than zero exception is thrown.
     * Else if premium paid by customer is greater than base premium amount then
     * amount payable is 0.75 times of bill generated. Else if premium paid by 
     * customer is less than or equal to base premium amount and premium paid by
     * the customer is greater than half of base premium amount, amount payable 
     * is 0.45 times of bill generated. Else amount payable is equal to bill generated.
     * @param PremiumPaidByCustomer Premium paid by the adult in dollars
     * @param billGenerated Bill generated in the hospital in dollars
     * @return Amount an adult needs to pay to the hospital(Amount payable)
     * @throws NegativeAmountException If premium paid by the customer is less 
     * than zero then this exception is thrown
     */
    @Override
    public double calcAmountPayableToHospital(double PremiumPaidByCustomer, double billGenerated) throws NegativeAmountException {
        double amountPayable=0;
        if (PremiumPaidByCustomer < 0) {
            throw new NegativeAmountException("NegativeAmountException: Amount is less than 0");
        } else if (PremiumPaidByCustomer > BASE_PREMIUM_AMOUNT) {
            amountPayable = 0.75*billGenerated;
        }else if(PremiumPaidByCustomer <= BASE_PREMIUM_AMOUNT && PremiumPaidByCustomer > BASE_PREMIUM_AMOUNT/2){
            amountPayable = 0.45*billGenerated;
        }else{
            amountPayable = billGenerated;
        }
        return amountPayable;
    }

    /**
     * String representation of Adult insurance details print insurance company 
     * details and insurance coverage details.
     * @return  Adult insurance company details
     */
    @Override
    public String toString() {
        return "Insurance Company Name: " + super.getInsuranceCompanyName() + "Insurance Coverage: " + super.getInsuranceCoverage();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;
import java.util.List;

/**
 * Contains calculation of assigning doctor to a maternity patient and
 * calculation of bill
 *
 * @author Avinash Vasadi
 */
public class MaternityWard extends AbstractHospitalInfo {

    /**
     * Status of the appointment
     */
    private boolean appointmentStatus;

    /**
     * Initializes appointmentStatus to false and calls the super class to initialize
     * the variables that belong to super class.
     *
     * @param hospitalName Name of the hospital
     * @param hospitalAddress Address of the hospital
     * @param fName First name of the patient
     * @param lName Last Name of the Patient
     * @param insuranceID Insurance id of the patient
     * @param age Age of the Patient in years
     * @param gender Gender of the patient
     * @param lastCheckUpDate Last check up date of the employee
     * @param lastCheckUpStatus Last check up status of the patient
     * @param lastDoctorVisited Last doctor, patient has visited
     *
     */
    public MaternityWard(String hospitalName, String hospitalAddress, String fName, String lName, int insuranceID, int age, char gender, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited) {
        super(hospitalName, hospitalAddress, fName, lName, insuranceID, age, gender, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited);
        this.appointmentStatus = false;
    }

    /**
     * Assigning doctors to maternity patients. Pass doctorList
     * of type List of doctors as arguments. Iterate through the list of
     * available doctors. If appointmentStatus is true and if specialist type is
     * "Gynaecologist" set appointmentStatus to true, store the doctor name ,
     * store the patient first name and last name together in a variable name
     * called patientName. Add the doctor name appended with ":" to the patient
     * name to the getDoctorsMappedToPatients() List. Now remove the doctor from
     * the available doctors list.
     *
     * @throws SpecialistNotFoundException Throws if specialist doctor is not
     * found
     */
    @Override
    public void assignDocToPatient(List<Doctor> doctorList) throws SpecialistNotFoundException {
        String doctorName = "";
        for (Doctor doc : doctorList) {
            if (!appointmentStatus) {
                if ("Gynaecologist".equals(doc.getSpecialityType())) {
                    appointmentStatus = true;
                    doctorName = doc.getName();
                    String patientName = getfName() + " " + getlName();
                    getDoctorsMappedToPatients().add(doctorName + ":" + patientName);
                    //super.getAvailableDoctorsList().remove(doc);
                }
            }
        }
        if (!appointmentStatus) {
            throw new SpecialistNotFoundException("GynaecologistNotFoundException: There is no available doctors in the list who are child specialist ");
        }
    }

    /**
     * Calculates the bill based on type of disease. Initialize a variable bill
     * to 0.Fetch the billing details and split the details using comma as
     * separator and store them in an array called items. Use an enhanced for
     * loop and iterate through the list of items. If item is not null then 
     * calculate the bill based on disease. If "group B streptococcus"
     * add $18.75 to the bill. If "respiratory syncytial virus" add $21.29, If
     * "influenza" add $18.98, If "pertussis" add $17.5 Default bill will have the
     * emergency fee. Now return Base consultation fee and bill by summing up.
     *
     * @param billingDetails Billing details in the maternity ward
     * @return Bill patient needs to pay
     */
    @Override
    public double calcBill(String billingDetails) {
        double bill = 0;
        String items[] = billingDetails.split(",");
        for (String item : items) {
            if (null != item) {
                switch (item) {
                    case "group B streptococcus":
                        bill += 18.75;
                        break;
                    case "respiratory syncytial virus":
                        bill += 21.29;
                        break;
                    case "influenza":
                        bill += 18.98;
                        break;
                    case "pertussis":
                        bill += 17.5;
                        break;
                    default:
                        bill += EMERGENCY_FEE;
                        break;
                }
            }
        }
        return BASE_CONSULTATION_FEE + bill;
    }

    /**
     * A string representation of Maternity ward. Call Super class tostring and
     * append status
     *
     * @return Materniy ward details
     */
    @Override
    public String toString() {
        return super.toString() + "\nStatus=" + appointmentStatus;
    }
}

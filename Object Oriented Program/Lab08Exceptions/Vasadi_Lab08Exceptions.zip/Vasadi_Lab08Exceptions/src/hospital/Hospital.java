/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.List;

/**
 * Contains Hospital information
 *
 * @author Avinash Vasadi
 */
public interface Hospital {

    /**
     * Represents emergency fee in dollars for patients of type double. It is assigned to 30.0
     */
    double EMERGENCY_FEE = 30.0;
    /**
     * Represents basic consultation fee in dollars of type double. It is assigned to 20.0
     */
    double BASE_CONSULTATION_FEE = 20.0;

    /**
     * Calculates bill in dollars that a patient needs to pay
     *
     * @param billingDetails Details of the bill
     * @return Bill amount a patient needs to pay
     */
    double calcBill(String billingDetails);

    /**
     * Represents details of the specialist doctor who will address a specific
     * customer
     *
     * @param doctorList List of doctors
     * @throws SpecialistNotFoundException It throws an exception.
     */
    void assignDocToPatient(List<Doctor> doctorList) throws SpecialistNotFoundException;
}

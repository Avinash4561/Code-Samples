/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Adds the doctors and contains information of the hospital
 *
 * @author Avinash Vasadi
 */
public abstract class AbstractHospitalInfo extends Patient implements Hospital {

    /**
     * Name of the Hospital
     */
    private String hospitalName;
    /**
     * Address of the hospital
     */
    private String hospitalAddress;
    /**
     * Available doctors list of type List of Doctor
     */
    private List<Doctor> availableDoctorsList;
    /**
     * Doctors mapped to patients of type List of String
     */
    private List<String> doctorsMappedToPatients;

    /**
     * Initializes available doctors list to Array list of doctors. Also
     * initializes doctors mapped to patients to an ArrayList.
     */
    public AbstractHospitalInfo() {
        this.availableDoctorsList = new ArrayList<>();
        this.doctorsMappedToPatients = new ArrayList<>();
    }

    /**
     * Assigns each of the parameter value to the respective attributes. Calls
     * the super class constructor for the required variables to be
     * instantiated. availableDoctorsList and doctorsMappedToPatients are
     * initialized to an empty ArrayList
     *
     * @param hospitalName Name of the hospital
     * @param hospitalAddress Address of the hospital
     * @param fName First name of the Patient
     * @param lName Last Name of the Patient
     * @param insuranceID Insurance ID of the patient
     * @param age Age of the patient
     * @param gender Gender of the patient
     * @param lastCheckUpDate Last Check up date of the patient
     * @param lastCheckUpStatus Last check up status of the patient
     * @param lastDoctorVisited Details of the last doctor patient has visited
     */
    public AbstractHospitalInfo(String hospitalName, String hospitalAddress, String fName, String lName, int insuranceID, int age, char gender, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited) {
        super(fName, lName, insuranceID, age, gender, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited);
        this.hospitalName = hospitalName;
        this.hospitalAddress = hospitalAddress;
        availableDoctorsList = new ArrayList<>();
        doctorsMappedToPatients = new ArrayList<>();
    }

    /**
     * Returns the name of the hospital
     *
     * @return Name of hospital
     */
    public String getHospitalName() {
        return hospitalName;
    }

    /**
     * Returns the address of the hospital
     *
     * @return Hospital Address
     */
    public String getHospitalAddress() {
        return hospitalAddress;
    }

    /**
     * Returns the List of available doctors
     *
     * @return Doctors List
     */
    public List<Doctor> getAvailableDoctorsList() {
        return availableDoctorsList;
    }

    /**
     * Sets the available list of doctors
     *
     * @param availableDoctorsList Available doctors list
     */
    public void setAvailableDoctorsList(List<Doctor> availableDoctorsList) {
        this.availableDoctorsList = availableDoctorsList;
    }

    /**
     * Returns the List of doctors mapped to patients
     *
     * @return Doctors mapped to patients
     */
    public List<String> getDoctorsMappedToPatients() {
        return doctorsMappedToPatients;
    }

    /**
     * Returns the Emergency fee in dollars
     *
     * @return Emergency fee
     */
    public static double getEMERGENCY_FEE() {
        return EMERGENCY_FEE;
    }

    /**
     * Returns the base consultation fee in dollars
     *
     * @return Consultation fee
     */
    public static double getBASE_CONSULTATION_FEE() {
        return BASE_CONSULTATION_FEE;
    }

    /**
     * Adds doctors to the getAvailableDoctorsList
     *
     * @param doctor doctor of type Doctor
     * @throws InvalidDoctorSizeException Throws if the doctors list size is
     * less than 0.
     * @return available doctors list
     */
    public List<Doctor> addDoctors(Doctor doctor) throws InvalidDoctorSizeException {
        if (this.getAvailableDoctorsList().size() < 0) {
            throw new InvalidDoctorSizeException("InvalidDoctorSizeException as arrayList size cannot be negative");
        } else {
            this.getAvailableDoctorsList().add(doctor);
            return this.getAvailableDoctorsList();
        }
    }

    /**
     * Assigns a doctor to a patient
     *
     * @throws SpecialistNotFoundException Throws if specialist is not found
     */
    @Override
    
    public abstract void assignDocToPatient(List<Doctor> doctorList) throws SpecialistNotFoundException;

    /**
     * Abstract method to calculate the bill in dollars
     *
     * @param billingDetails Details of the bill
     * @return Bill that needs to be paid
     */
    @Override
    public abstract double calcBill(String billingDetails);
}

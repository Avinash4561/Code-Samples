/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cards;

/**
 * A Card class
 * @author Avinash Vasadi
 */
public class Card {

    public int number;
    public String Type;
/**
 * 
 * @param number A constructor to set number
 * @param type  A constructor to set type
 */
    public Card(int number, String type) {
        this.number = number;
        this.Type = type;
    }
/**
 * 
 * @return number
 */
    public int getNumber() {
        return number;
    }
/**
 * 
 * @param number A method to set a number
 */
    public void setNumber(int number) {
        this.number = number;
    }
/**
 *  A method to return Type
 * @return Type
 */
    public String getType() {
        return Type;
    }
/**
 * 
 * @param Type A method to set Type
 */
    public void setType(String Type) {
        this.Type = Type;
    }
/**
 * It overrides the inbuilt toString method
 * @return a value of string
 */
    public String toString() {
        return String.valueOf(getNumber());
    }

}

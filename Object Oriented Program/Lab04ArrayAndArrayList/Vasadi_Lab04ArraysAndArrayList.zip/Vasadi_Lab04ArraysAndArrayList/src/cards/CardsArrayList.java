/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cards;

import java.util.ArrayList;

/**
 *
 * @author Avinash Vasadi
 */
public class CardsArrayList {

    public ArrayList<Card> clubs;
    public ArrayList<Card> diamonds;
    public ArrayList<Card> hearts;
    public ArrayList<Card> spades;
/**
 * A constructor with no arguments
 */
    public CardsArrayList() {
        clubs = new ArrayList<Card>();
        diamonds = new ArrayList<Card>();
        hearts = new ArrayList<Card>();
        spades = new ArrayList<Card>();
    }
/**
 * 
 * @return clubs
 */
    public ArrayList<Card> getClubs() {
        return clubs;
    }
/**
 * 
 * @return diamonds
 */
    public ArrayList<Card> getDiamonds() {
        return diamonds;
    }
/**
 * 
 * @return hearts
 */
    public ArrayList<Card> getHearts() {
        return hearts;
    }
/**
 * 
 * @return spades
 */
    public ArrayList<Card> getSpades() {
        return spades;
    }
/**
 * 
 * @param c A method taking a card object
 * @return cards added to list
 */
    public String addCardsToList(Card c) {
        switch (c.Type) {
            case "clubs":
                clubs.add(c);
                return ("card added successfully");
            case "diamonds":
                diamonds.add(c);
                return ("card added successfully");
            case "hearts":
                hearts.add(c);
                return ("card added successfully");
            case "spades":
                spades.add(c);
                return ("card added successfully");
        }
        return null;
    }
/**
 * 
 * @param position A method it position as argument
 * @param c argument of a method
 * @return status of removed cards
 */
    public String removeCardsFromList(int position, ArrayList<Card> c) {
        if (position < 0 && position > c.lastIndexOf(c)) {
            return ("ArrayList size underflow, card cannot be removed");
        } else {
            c.remove(position);
            return ("Card is removed successfully!");
        }
    }

    @Override
    /**
     * Overriding inbuilt toString method
     */
    public String toString() {
        String clu = "";
        String dia = "";
        String hea = "";
        String spa = "";
        for (Card m : clubs) {
            clu = clu + " " + m + " ";
        }
        for (Card n : diamonds) {
            dia = dia + " " + n + " ";
        }
        for (Card o : hearts) {
            hea = hea + " " + o + " ";
        }
        for (Card p : spades) {
            spa = spa + " " + p + " ";
        }
        return ("Hearts ArrayList:[" + hea + "]\n" + "Diamonds ArrayList:[" + dia + "]\n"
                + "Spades ArrayList:[" +  spa +"]\n" 
                + "Clubs ArrayList:[" + clu + "]");

    }
}

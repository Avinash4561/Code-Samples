/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cards;

/**
 * This is a cards array class in which we use arrays to store cards.
 *
 * @author Avinash Vasadi
 */
public class CardsArray {

    private Card[] clubs;
    private Card[] diamonds;
    private Card[] hearts;
    private Card[] spades;
    private static final int DECK_SIZE = 5;
    private int clubscount;
    private int diamondscount;
    private int heartscount;
    private int spadescount;

    /**
     * This constructs a no argument constructor which initializes the variables
     * to defaults and initializes the arrays.
     */
    public CardsArray() {
        this.clubs = new Card[DECK_SIZE];
        this.diamonds = new Card[DECK_SIZE];
        this.hearts = new Card[DECK_SIZE];
        this.spades = new Card[DECK_SIZE];
        this.clubscount = 0;
        this.diamondscount = 0;
        this.heartscount = 0;
        this.spadescount = 0;
    }

    /**
     * A method to return clubscount
     *
     * @return count of clubs.
     */
    public int getClubscount() {
        return clubscount;
    }

    /**
     * A method to return diamondscount
     *
     * @return count of diamonds.
     */
    public int getDiamondscount() {
        return diamondscount;
    }

    /**
     * A method to return the hearts count
     *
     * @return count of hearts.
     */
    public int getHeartscount() {
        return heartscount;
    }

    /*
     * A method to return the spadescount 
     * @return count of spades.
     */
    public int getSpadescount() {
        return spadescount;
    }

    /**
     * 
     * A method to add a card to an array
     * @param c Card object
     */
    public void addCardsToArray(Card c) {

        if (c.getType().equals("clubs")) {
            if (clubscount >= DECK_SIZE) {
                removeCardsFromArray(0, c.getType());
                clubs[clubs.length - 1] = c;
                clubscount++;
            } else {
                clubs[clubscount] = c;
                clubscount++;
            }
        } else if (c.getType().equals("diamonds")) {
            if (diamondscount >= DECK_SIZE) {
                removeCardsFromArray(0, c.getType());
                diamonds[diamonds.length - 1] = c;
                diamondscount++;
            } else {
                diamonds[diamondscount] = c;
                diamondscount++;
            }
        } else if (c.getType().equals("hearts")) {
            if (heartscount >= DECK_SIZE) {
                removeCardsFromArray(0, c.getType());
                hearts[hearts.length - 1] = c;
                heartscount++;
            } else {
                hearts[heartscount] = c;
                heartscount++;
            }
        } else if (c.getType().equals("spades")) {
            if (spadescount >= DECK_SIZE) {
                removeCardsFromArray(0, c.getType());
                spades[spades.length - 1] = c;
                spadescount++;
            } else {
                spades[spadescount] = c;
                spadescount++;
            }
        }
    }

    /**
     * 
     * 
     *A method to remove a card from an array
     * @param position position at which the card is to be removed.
     * @param cardType type of card
     */
    public void removeCardsFromArray(int position, String cardType) {

        if (cardType.equals("clubs") && position < (clubs.length) && position >= 0) {
            if (position == (clubs.length - 1)) {
                clubs[position] = null;
                clubscount--;
            } else {
                for (int j = position; j < clubs.length - 1; j++) {
                    clubs[j] = clubs[j + 1];
                }
                clubs[clubs.length - 1] = null;
                clubscount--;
            }
        } else if (cardType.equals("diamonds") && position < (diamonds.length) && position >= 0) {
            if (position == (diamonds.length - 1)) {
                diamonds[position] = null;
                diamondscount--;
            } else {
                for (int j = position; j < diamonds.length - 1; j++) {
                    diamonds[j] = diamonds[j + 1];
                }
                diamonds[diamonds.length - 1] = null;
                diamondscount--;
            }
        } else if (cardType.equals("spades") && position < (spades.length) && position >= 0) {
            if (position == (spades.length - 1)) {
                spades[position] = null;
                spadescount--;
            } else {
                for (int j = position; j < spades.length - 1; j++) {
                    spades[j] = spades[j + 1];
                }
                spades[spades.length - 1] = null;
                spadescount--;
            }
        } else if (cardType.equals("hearts") && position < (hearts.length) && position >= 0) {
            if (position == (hearts.length - 1)) {
                hearts[position] = null;
                heartscount--;
            } else {
                for (int j = position; j < hearts.length - 1; j++) {
                    hearts[j] = hearts[j + 1];
                }
                hearts[hearts.length - 1] = null;
                heartscount--;
            }
        }
    }

    /**
     * 
     * 
     *It overrides the inbuilt toString method
     * @return concatenated String of type String.
     */
    @Override
    public String toString() {
        String heartsArray = "Hearts Array:[";
        for (Card heartvalue : hearts) {
            if (heartvalue != null) {
                heartsArray = heartsArray + " " + heartvalue + " ";
            }
        }
        String diamondsArray = "Diamonds Array:[";
        for (Card diamondvalue : diamonds) {
            if (diamondvalue != null) {
                diamondsArray = diamondsArray + " " + diamondvalue + " ";
            }
        }
        String spadesArray = "Spades Array:[";
        for (Card spadevalue : spades) {
            if (spadevalue != null) {
                spadesArray = spadesArray + " " + spadevalue + " ";
            }
        }
        String clubsArray = "Clubs Array:[";
        for (Card clubvalue : clubs) {
            if (clubvalue != null) {
                clubsArray = clubsArray + " " + clubvalue + " ";
            }
        }
        return "\n" + heartsArray + "]\n" + diamondsArray + "]\n" + spadesArray + "]\n" + clubsArray + "]";
    }
}